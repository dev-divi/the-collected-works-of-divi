# A Different Pursuit

`They worship Me in vain; they teach as doctrine the precepts of men.’`

This is a similar concept, that man preaches his own culture's laws through religious verbiage.

In the same way, the ego that finds religion takes God as a means to preach his justice.
This justice shows the state of expansion they are currently at.
This is a personal brand of justice based on the idea that I am right and you are wrong and you will suffer for it.
This is how the ego attempts to protect itself from further suffering.

This justice has a few limitations, for one, it is created by a limited intelligence.
Second, an eye for an eye makes the whole world blind.

Even knowing this, even if one understands this, the ego finds itself the inability to let this go,
for fear of pain.
There is fear that the ego will be left alone in the dark, that something untrue will have occurred and this wrong will never be righted, this error will never be corrected.

A person does not know it, but all people defend truth, that is why they do not want to be wronged. To have someone wrong you is to have them commit a crime against you,
such like lie about you. A lie is untrue and you know it.
In the same way, when a person wrongs you, they should not have hurt you and you know it.

The problem is not that you were hurt, but that you know that this should not have happened,
this thing that has happened is a statement and a testimony against you,
and you know that had they accurately valued you, they would not have done this to you,
therefore an error has occurred and you know it.
In seeking justice, you are wanting for this error to be corrected,
such that there is a correct testimony in which you are accurately valued.

This is why man pursues his justice.
However, figures like Christ preach a different way.
They say to forgive your enemies.
This is a different way than that of the limited ego.