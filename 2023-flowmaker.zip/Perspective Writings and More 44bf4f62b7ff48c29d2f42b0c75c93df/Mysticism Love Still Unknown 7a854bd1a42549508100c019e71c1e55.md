# Mysticism: Love Still Unknown

Mysticism, something real,
a majority of my writings focus on the practical applications of the spiritual life in the physical world.
It is refreshing to instead be inspired to write on a focus deeper, more real, and more honest.

> *Love, still unknown,  why do you leave me? 
Love, still unknown, why why why?*
> 

[https://youtu.be/lJfPdt9zKvE?si=j0PaTvt8lwQO-ULa](https://youtu.be/lJfPdt9zKvE?si=j0PaTvt8lwQO-ULa)

This text arouses a lifetime of hidden spiritual experiences laying under view, with no tangibility to be remembered.
Surely, in the darkness, they are forgotten to be dissolved, there is no reason for their remembrance,
their light is ‘trickery’.

<aside>
💡 Before I can comment on spiritual experiences, I need some kind of a reference to point you towards to have an idea of what these experiences entail, and so here are the easiest to point at, those which are large scale, not individuated experiences.

</aside>

<aside>
💡 **Sorcerer's Playground** 

The easiest reference to point to as example is *‘Carlos Castaneda*’. My experience of the dimension which Carlos evokes is so strikingly visible to my ‘*discernment’* with a layer of 'demonic energy', that compared to other experiences, is nearly crude. 

Carlos' spiritual dimension he points to is one where strange and odd things happen, where darkness and chaos play openly, and where magicians thoughtlessly conjure. Its visible layer holds the taste of a full wine and drunk of darkness, but the darkness is yet not dark enough to cloud the pain of evil behind it. The layer behind it is sharp glass behind the mirror, it is callous and rough and jagged and coarse.

Rather than the drunk of the visible layer satiating the soul, the corruption of the hidden layer instead makes the soul feel sick and looking for a place to upheave.
This is such the same as when one sees inorganic symbols, designs with no reason, that which is ugly.
This is the same to say as sentences which have no flow, paragraphs with no association to the next, and bad art.

</aside>

<aside>
💡 **The City of Night**

The abstract darkness as a dimension I have encountered in a city that is not Carlos*' 'sorcerers dimension',*

is instead a far cleaner *drunkenness of soul.*
There are feelings of power, madness, expansion, liberation, ecstasy, these are easy to disassociate into and ride along with.
Whatever evils exist under layers are less perceptible, and no ill intentions are keenly discernable.

It is in some of these as though a single entity or mind has swept the whole of a place, a shadow that has not spoken, resting in silence and masking its intention, or holding no current intention at all. These, I assume, pay little attention to a single human vessel, as they will long outlive a person.

</aside>

I point out two ‘large’ spiritual experiences, the crude and the advanced, to point out realms of spiritual darkness that are easily observed.

I will point out major gains and losses from the exposure to these in the soul,
then considerations of them.

**The intrinsic gain from the darkness is,**

- a temporary sort of rest from problems and stresses,
- a bliss or feeling of light which the soul craves, a pleasure,
- a feeling of flow

**the losses,**

- a pain around the soul,
- a feeling of a slow drain,
- a sort of coming to stillness as such near to death,
- the awareness of negative forces in the world or personal psyche,
- a slow loss of one's essence of their light of day, their waking personality and characteristics
- the cold which grows in isolation
- the undesirables, including the threat of a nakedness of exposure to the light.
The nakedness of exposure to the light is where your soul feels that its corruption is covered by a thin sheet of innocence,
the thin shield of spiritual drink and power is not enough to mask the threat of
the pain of vulnerability becoming exposed to the light,
of the true helplessness and weakness of the naked core of the soul being revealed,
of the free truth being revealed.
- another loss is that it feels that the mind is not being recharged by this spiritual power, thus a mental fatigue grows and such enjoyment
dulls to unpleasantness, and the comfort ego attempts to take within its state is unable to cover up one's suffering.
- another loss is the feeling of discrete mental sickness.

These gains and losses can change based on the specific experience one is exposed to, but there are some general commonalities
that come with experience.

**Ultimately, one who is lucky may learn that states of darkness are devoid of love,**

and to be devoid of love is to watch your flesh rot into a living corpse, to watch the light disappear from your eyes, and lifeless appear from your essence, as a light of the world which has lost its salt, having no flavor.

There are many kinds of 'love' that are attainable within darkness, such as in states of intimacy, but there is not the love which cures the delusion of isolation and loneliness. Certainly, a person shrivels in darkness.
They lose strength, and become frail. They retreat and recluse,
and they may not pull themselves out unless another comes for them.

What is true for me in this is that even writing about such darknesses, I feel the loss of my creative life, and the initial desirable draw toward these darknesses is replaced by the sickness in exposure to wickedness  *—that of ill intention, malice, harm*. 

There are times where the night is full of drunken drink, and which I can drink without feeling such loss, and without feeling wicked influence,
but when the association is drawn towards Carlos' ideas or that of other occult influences, such enjoyment evaporates.

**Now to address the woman at hand and what she experienced in her soul,** 

this beautiful and tormented ******Angela of Foligno.******

The first question is, what kind of light was her soul being drawn towards, what was the purity her soul longed to gain in darkness?
There is also the matter of what existed for her within this darkness, and what associations came with these experiences.

Based on the associations I see her in relation to in this darkness, I feel that I can relate to the spiritual depths she experiences,
namely in a few key statements,

- *her desire to be rid completely of her world to seek intimacy with the single desire calling to her,*
- *her association to the divorce of her sexual desires of the flesh,*
- *her association to the demons inside of her which tempted desires of the flesh to be associated with the darkness,*
- *her longing for God to return from abandoning her within darkness,*
- *and finally her sexual union with God.*

What I write beyond this point is purely analytical and without judgement, because I do not believe to have the mature understanding of this
data which I will one day have.

Unlike other focuses in which I am able to write in a linear way, there is no linear way for me to approach my understanding of these experiences, and it is unlikely that I will capture most of my meaning.

**To start then, is the experience of the darkness and desire.**

The darkness is a comfort, it is merged with the light of bliss in nothingness.
Darkness as location, and its substance which fills that location, assuming it is not obviously muddled with other energies,
these are nearly seamlessly one experience.
There are two desires, and yet one of the desires calls to go deeper.

**The first desire is to take comfort and rest and fall within darkness,** to contract and recluse, to shut out the light of consciousness such that only the darkness remains, in which there is no memory of any distraction from the second desire,
to shut every curtain and end all noise, that the night finally wins out,
such that the threat of tomorrow does not come and there is nothing left to obstruct the pure experience of the treasure in hand.
This is be the same desire as when you behold something you want, and you have the desire to go into private with it such that it can become your sole and complete focus, that nothing else exist in reality.
This first desire can include the complementary desires as the desire to isolate, to be alone, not to just be alone, possibly even to fall deep into loneliness or aloneness, even as a destructive and negative experience.

**The second desire is of course to become totally full and complete of the light of bliss.** This desire is not only the desire for attainment,
it is also a deep yearning and cry in the soul, the yearning itself is an experience, the bliss to fill one's cup is an experience,
and the emptiness of the cup is also an experience.
Surely, to fill one's cup entirely would mean the person would disappear into nothingness, and the person would not be there to have the experience,
and surely the mind still seeks it if it has become possessed by this desire.

To Angela, that light which exists within that darkness, which her soul wishes to possess, this is the holy trinity, the father god, the son of god; The light of perfection, Christ, and finally, the holy spirit, purity itself.
Now, when I have taken a look at catholic ritual and symbology and art and architecture, I see and feel the light of this purity which it seeks to obtain, the white marble, the innocence of a virgin.

Knowing this spiritual pure bliss, —*especially as I meditate on it as I write these words*, I can understand why this woman sees this as her love for God, her devotion to God. I can see why she would call this love. Love in this sense, is in part, this strong pursuit.
However, to me, this is not the love which destroys isolation.

Now, Angela also mentions experiencing a unity and oneness with all, and this to me still is not that oneness of connection which fills the heart with warmth and ends aloneness, rather this oneness is the oneness that is of mind, that the within has also become without, that the reality has become a totality.

<aside>
💡 **This is where I write without a final judgement on the matter, but I believe this insight should be illuminating.**

</aside>

<aside>
💡 
First, consider a decision to surrender all to God.

</aside>

<aside>
💡 Now, consider the desire to have nothing else besides the treasure you have found, that which you want.

</aside>

If you meditate on these two, you will see that they are not the same,
and yet they are very much the same.

What are the differences?

In Scene 1, we could consider the ancient idea of renouncing desire. Now, let's add the more modern Christian concept of ‘handing our overwhelming desires to God’.

In Scene 2, consider that you have ten desires, but one of them is more tempting than the others. Surely, you would want to rid yourself of the others.

At least in Catholic imagery, innocence and feminine beauty are essentially pure and holy.

Under the surface, as a thin layer, not unlike the hidden layers of dimensions mentioned earlier in this text,
is the hidden sexual nature of the beauty of these images. That which hides under this beauty is of a highly sexual nature.

As this is the case, it is no surprise to me that Angela would meditate on this image as the Christ, as God.
It is no surprise to me that "Brother Abe" would say that after her divine experiences, she radiated that holy, feminine, overpowering glow.

I have known such a glow, experienced in contact with Catholic symbology and architecture, I have also experienced it from places and times of darkness, I have also channeled it effectively through mantra techniques, I have also seen spiritually aware women directly channeling it and completely filling their auras and bodies with it such that they glowed bright.

Now, to me, this is not actually ‘God’. Were it a spiritual entity, it would be most likely classically considered as a highly powerful spirit of lust. This can be made sense of if you consider that a spirit does not desire company, it does not desire the company of other spirits.

From the perspective of a modern Christian model, a spirit of lust does not also desire also for spirits of murder, jealousy, death, contention, confusion, madness, depression, poverty, to all take residence within a home. A spirit desires to either have a home to itself, or at least to share board with familiar spirits, spirits which are similar to it.
Now, I don't necessarily think that this is a spirit of Lust, though if it were a spirit, it would be this spirit,
but to at least regard this experience as a singular desire,

I will explain the reason why I do not think this desire is the desire for God.

**First is of course that the nature of bliss is, essentially, perfect pleasure itself.**
The desire for perfect oneness with the image of the symbolic Christ which the woman desires is also beautiful, perfect, desirable.

That Angela’s soul would shriek out in yearning for the desire to be totally fulfilled is also not surprising, to have that which you want,
and also be unable to grasp it, this is a tear which cannot be fixed.
It is as though you have the desire for brokenness in your soul, for the two to be apart, and not together.
It is as though the desire is the desire for the desire to be unfulfilled,
that the pleasure being gained from the soul is within the yearning itself,
this means that the yearning can be increased, but the desire can never be fully satiated, such that the yearning would cease.

This means that her love is for the love itself, the yearning itself.

**Were this to be prolonged for eternity, with the soul not receiving real love and warmth from the outside, from the outside of aloneness,**
this would create a kind of eternal agony in which a person would be in hell.
Now, you could argue that this is only a temporary dark night of the soul, that the person would eventually break and find a liberation within such suffering, but I would not agree that such liberation would also end the hell.
It would be liberation within hell, still a hell.

**So I will point out a couple of perceived "mistakes" with these conclusions here.** The first is that these images of 'piety' and 'purity' are purely conceptions and ideas and ideals of the limited mind of man, as evidenced by the fact that we can look back at these times in cultures and see how they have changed. They are not in regard to the mind of God.

The difference in philosophy which I am exposed to regards a discernment.
The first discernment is that the experience of the living Holy Spirit does not include a lustfulness,
*—though that aspect or location of my soul also exists*. Such has been described to me by some as a "False Holy Spirit", and I am now at the level of maturity to begin to understand what they had meant.

Here is the difference in philosophy,
is the concept to not only let go of desires,
but to *desire what God desires*.

This is subtly different from simply *desiring God*.

To simply *desire God* might be on point, if you know the direction of God.
Surely beauty is in the direction of God, and yet humans fall far from God into wickedness in the pursuit of it.

To simply desire God perhaps is a good start, at least you have set a direction and a course,
but it lacks the ability to modify that course in case your initial data was inaccurate.

If instead, you apply the idea of pursuing to *"desire what God desires"*, then you have a chance at self-correction over time.
Self-correction over time could be considered as the pursuit of wisdom, because you are refining and changing and becoming changed by the exposure to outside information over time.

If you already know from the start exactly what God desires and are perfectly pursuing that, then congratulations, you are either connected directly to God and should need no advice from mankind on this matter, or you are simply the wisest person on Earth. The latter is unlikely to be the case.

From setting the direction to pursue what God desires, there are two directions you could take from the start.
The first is you could simply decide who God is based on what you like, and pursue that.
The second is you would apply this concept, *"seek to learn God's heart."*

Now you are not simply looking to learn what God desires,
but now you are looking to learn the desires of God's heart.

This is, basically, a miraculous possibility,
because you also have a heart,
and this means that if you gain the desires of God's heart within your own heart,
then your heart and God's heart are aligned,
what a connection to have!

One of the benefits of this approach is that the biblical canon, both the Old and New Testament,
these both often reference *God's heart*.
While pursuing to read the bible might leave you with any set of beliefs of what God is based on interpretation or what others have told you, 
focusing specifically on references and associations to God's heart in scripture can allow you to build a model of what that could be.

In this pursuit, you would assuredly give up such a strong possessive desire to God, you would surrender this desire for him, because it gets in the way of the desires of God's heart.

So, I will just answer a major desire of God's heart here.
God's heart is for you to not be alone, in loneliness.

This does not mean he does not lead you through darknesses, or does not lead you to isolate, or meditate, or recluse, in order that he can speak to you or process, but it means that in the ultimate story of your life, he intends for you to be well connected to his network, such that you are not deluded in the lie of aloneness, abandonment, and isolation which is spiritual darkness.

---

**There is evidence that this is the will of God to lead you out of total aloneness,**

 **in that spiritual maturity is largely related to your maturity as an ego.**

A spiritually young person is one who is more spiritually alone in this world. As a person expands in connection with this world, their limited ego expands to a world beyond them. The smallest people are not the less intelligent or less capable,
rather they are the less expanded humans.
This means that their story of reality includes only them and no one else.
If you want to look at the easiest pointer to spiritual maturity, look at this,
does the person know of a world outside of their personal story,
do they believe that others have suffering such as their own,
or do they believe that they alone are uniquely troubled in this world?

God leads your soul to eventually expand up to the world,
not unlike how his beloved son, the Christ, also expanded his heart to the whole world.
*--This does not mean that God intends for you to expand your heart to the entire world at this stage of your existence of course.*

It is God's long term will to expand your soul to connection with others.
Surely there are periods he intends to take you into deeper spiritual intimacy with him,
but overall, he surely intends for you to extend out into your world to receive love from others.

This is evidenced by the characteristics he created which are of a godly and divine nature,
such as strength, courage, freedom, these characteristics are 'extroverted' in their nature,
they point outwards out to the world, such like a plant reaches for the sun.

This metaphor is not unlike reality,
neither is the son of God.
It is no coincidence that the son of God is a king, with attributes of glory and righteousness,
as a character who is bold and holds authority, and is highly active,
these are attributes of the sun, of the day.
Notice that things come to rest at night, and take action during the day.

Notice that the son of God is an active character, not a passive character.
This character also represents God's love,
which tells us that this love is an active love, not a passive love.
This love is one which expresses itself in the physical world,
not a love which hides itself in darkness.

Surely, God too created the night, and intended for us to have love in intimacy in the dark,
the space in which trust is formed,
faith is formed within darkness.

It is our mind, which attempts to solve each of our problems permanently, which leads us toward *absolute* choices,
such as to abandon the world, to recluse in isolation forever.
The one with discretion will find this to be a sure red flag that the self or ego or mind is at work to achieve this ultimate solution to end its problem,
as to recluse from the light of day entirely is the way the ego intends to shield itself from the pains of this world,
not just the sight of the evils within it,
but to be shielded from the pain of failure in relationships.

---

To say that her desire, as well as the 'false holy spirit' that I have known is a spirit of lust,
is not to point out that a spirit of lust would be evil or wrong.

It is to point out the nature that it is one which is not fulfilling or restorative to the soul.
It provides the asset of pleasure, but it is not a sustainable source of energy,
and instead drains from the person.

---

However, I deeply resonate with this holy place Angela spends these apparently great periods of time, in my experience I do believe that God intends to fill our souls in these deep, deep places of darkness and intimacy, 
yes, the very same spaces which the demons and their desires like to occupy. 

It is relevant that two nights ago, something had changed at night for me. It is usually that after the light of day, I have a desire to escape from stress. 
Those two nights ago, I noticed the release from that desire, instead was simply the desire to be at peace with the holy place in my heart, and this holy spirit which has taken residence in it.

<aside>
💡 I notice the relation between Angela’s longing for something in the soul as similar to that of artists, notably performance artists, and especially that of Marina Abramović. and Alex Grey, though I suppose these artists are not far from mystics.  
I also am reminded of a Buddhist poet who wrote poems about his deceased lover, and analyzed his experiences of love for that which was not in his world, 
while Angela is likely light years beyond that monk in spiritual depth, there is a similar curiosity which is explored in these intricacies of her desire for attainment of her love.

</aside>

I look forward to reading Angela’s works.

Thanks for Reading.