# Project Inspiration WAR — Vision

---

## I. Imagination Prayer Techniques

Idea Bottle - Person - Open Bottle

## II. Infinite Wish

New Start - Extension of Blessing - Includes envisioning a person's morning/ day starting well, eyes bright and open

## III. Idea Rituals

Resurgence of the understanding of imaging the future through the use of
the physical world

- - Idea Bottle Ritual involves taking a bottle filled with
- ideas
- magic
- power
- idea itself

and opening it

## IV. Ideas Rain

Paradigm Shift

Spread of idea rituals would cause rapid growth and accelerated change
in the collective, shifting not only the available mental faculties of individuals but changing how masses are perceiving creative access,
thinking about creative possibilities,
scope,
scale,
and probability of successful image out-picturing
ultimately thinking from a fresh, expanded, healthier perspective