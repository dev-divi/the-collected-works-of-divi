# Do you know who you are?

Do you know who you are, 
And are you living as who you really are?
Are you living as your best self?
Are you living your best life?

Because if you are not living your best life, you are not living as your best self.

If you are not living your life to the fullest, in its fullness, 
Then you are not living as your full self.

That means that you are not who you think you are, you are not being the real you.

That is why people are saying, you are not your mind. Because your mind, who you think you are, isn't the real you.

You say, I will suffer now, and I will live my best life later. This statement is impossible. 
You will never live in a reality of more by living in a reality of less.

These are two different realities. 
Reality is created by the current you. 

The current version of you is what creates reality now. 
This reality only contains this reality. 
A reality in which you are lacking will never become a reality in which you are fulfilled.