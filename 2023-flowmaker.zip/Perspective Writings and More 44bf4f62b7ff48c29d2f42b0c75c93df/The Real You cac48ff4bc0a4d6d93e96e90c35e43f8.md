# The Real You

The reason why it is said that there is only one way to find god is not because there is a correct religion. It is because in infinity there is only one direction that points to the real you. 

Consider this. Is there a real you? 
If there is a real you, if there is one real you, 
then there is only one way, the way to the real you. 
If you point a way in a different direction, you would arrive at a different destination. 

The way I am speaking of is a way of action and nature, 
If you do have a real spirit, that spirit has a way, 
there are many ways you could take but only one way is the way of your spirit. 

There are many paths you can take but there are only two directions that path can take you, you can either go closer to the real you, or farther from the real you. 

So this fire that comes, what it does is it kills what isn't the real you. 

In actuality this is just a poetic way to say that what is not real disappears because it is not real.

What this all means philosophically speaking is that you are good and worthy and deserving of life because you are life.

This is why they were badly mistaken, *his God was not the god of the dead but of the living.*

Another way to say it is that **the real you is the ultimate possibility of your existence.**

And **the ultimate possibility of your existence is life,** 
that **the miracle of life is the ultimate possibility of existence.**

> *"There is nothing you can get in life without paying for it, 
And you get it only as much as you are ready to pay for it. 
When you are willing to pay your life, you get eternal life in return. 
Nothing is free. Nothing can be free."*
>