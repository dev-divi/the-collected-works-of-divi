# Love in Life

![https://miro.medium.com/v2/resize:fit:568/1*oI80cZ1A18jUNNae_U7Byg.png](https://miro.medium.com/v2/resize:fit:568/1*oI80cZ1A18jUNNae_U7Byg.png)

*Love is a way of action because it must be demonstrated in order to be recognized. Love is freedom because love gives you the courage to act.*

# **Love is Mattering.**

Perhaps the reason people do not know what love is,

is because they know of love such as a state of being or as a certain mode of a person.

A person has many states, and many modes,

and who can really say that the loving mode is better than the aggressive mode or the sad mode?

It’s certainly seems plausible or tangible that love might be comparably better than some of these other modes,

but does it really matter which mode is best? After all, they are all going to come and go no matter what you do.

If you believe the scriptures,

It is written,

> “God is Love.”
> 

Certainly, ancient wise men would not write that God is simply a human mode.

This Love must be something bigger, more important than a mode for it to be comparable to the infinite, ultimate God of the universe.

The things that come and go, like our moods, thoughts, perceptions, these things which change like the weather does not seem to matter.

Then, if “Love” is a passing, temporary phenomenon like a cloud, then to say that God is Love is to say that He is something that does not matter too much.

> Jesus answered, ‘Hear..The Lord our God, the Lord is one.’
> 

We should assume that God matters very much, after all, Christ, who appears very wise, states that we should Love God above everything else, with our all.

> ‘Love the Lord your God with all your heart, with all your soul, with all your mind, and with all your strength.’
> 

<aside>
💡 — Notice the similarity between Christ’s statements, he says the Lord is ‘One’, and we should love God with ‘All’. 
One and All are related. 
The Lord is ‘Allness/Oneness’, and Christ instructs us to love the Lord with ‘Allness/Oneness’, 
and you might recall that he described being ‘One with his Father.’

</aside>

Christ seemed to think that God and Love mattered more than anything else.

Then, whatever Love is, we can know one of its attributes is that it matters very much.

And, we can know that if the love we are talking about, such as a mode, does not matter too much, then it is likely not Love.

I do like to say that Christ’s Love is a *possibility*,

<aside>
💡 *— that out of the possible ideas that can be conceived of, Christ’s love is one of those ideas actualized as a possibility if you will, an idea activated, made from inactive to active.*

</aside>

But what is the possibility?

Love is a way of action,

To receive love you must be given love,

the gift of love is called an act of love.

An ‘action’ comes from an ‘act,’ so we are talking about a way of action.

So to consider God’s love, well then, the act must be great, grand, if it is deserving of that title.

<aside>
💡 — A way of action creates reality. 
A way of Love is one possible reality actualized.

</aside>

# **Love is Valuable.**

Surely, complacency and niceness, the Beatles songs, they do not seem to meet the mark of what we’re talking about.

## **Why? What makes the difference?**

It’s easy to be nice when *everything* is pleasant.

To be common, to have everything *even,* we know this cannot be Love, because the common is not uncommon,

the value of common is common value.

So we know and can contrast that common niceness is not Love, nor is it God, because it is not of great value.

Pleasant things are pleasant.

To be nice to something pleasant is not a gift of love,

It is common decency.

To be decent is not of any special merit.

I promise I will not feel that you greatly love me because you have been decent to me, if decency is the current norm.

However much I appreciate and respect that you have honored me in being decent to me, which is a kindness,

this doesn’t mean you greatly love me.

<aside>
💡 *— Note, in the world as it is at the time of this writing, perhaps being decent to another person could be an act of great love, **if decency is not the norm.** If something is the norm, it is not an act of love.*

</aside>

# **Love is Unexpected.**

It is uncommon to regard a person as highly valuable. It is “out of the way”, not common, not what is expected, maybe even unexpected!

So to greatly love me, you would have to think more of me, to think I am more valuable than something common,

but thinking this is not enough,

to love me, you would have to show that to me, you would have to at least open the door to your love before I could feel it.

You would have to demonstrate it to me somehow,

that you are **capable of accurately appreciating** and valuing me,

And that I should believe you, and not also think you are deranged madman.

If you adorn me with gifts, if you shower me with treasures,

I am not going to think you love me.

I’m going to think something is the matter with you.

# **Love is Real.**

Now what about someone, a real friend. What makes them a real friend?

How do you know they love you?

You say, he’s a real friend, he would jump in front of a bullet for me.

Here’s something, it is said God is Love.

What if I said,

God is Real.

Now notice that when I said,

real friend,

The concept of a real friend happened to involve love.

Love is something that involves something real.

The closer to love you are, the more real you are also.

You have heard that you are love,

Consider it,

the more love you have the more real you are,

The more real you are the more love you have,

This equation means that you are love.

In one sense, love is your real nature.

Now, we’re talking about your real nature,

Surely we are not talking about one of the modes of your being.

# **Love is Character.**

Now there is something else that makes Love real,

The demonstration of it.

Not just that the action happened and existed in reality,

but that there is something real about demonstrating action that aligns with what is real for you.

The actual act of demonstrating love makes one feel more real.

If something makes you feel more real, it’s because it’s more of the real you,

Which means the real you, is someone who takes authentic action,

And someone who takes authentic action has certain characteristics.

<aside>
💡 — Characteristics, attributes of Love, these correlate to the real you.

</aside>

To take authentic action, one has characteristics of determination, boldness, strength, righteousness,

which means these characteristics must be your authentic characteristics.

That means to demonstrate love and also to embrace these characteristics you would become more of the real you.

# **Love demonstrates a realistic appreciation of value.**

God’s Love appears as being or involved with a way of action that demonstrates a realistic appreciation of value of the receiver.

Love is made more strikingly clear when the stakes are higher for the giver, when the giver clearly risks or loses in order to give the gift.

Love is made clear when a person behaves contrary to what is expected, or directly against opposition, at risk of rejection or ridicule or slander or crime in order to demonstrate love.

Such a demonstration is not only a gift to the receiver, a testimony of their real worth,

but it is a testimony to the value of all of humanity, not only in humanity’s worth as a receiver,

But in our real strength to be able to be capable of acting real, being real, despite any and all possible opposition.

# **Love can break the Matrix.**

This is why Love can break the Matrix. The Matrix is, in this sense,

your opposition. It is that which opposes you and confines you and binds you, which controls what you do and say, it is the invisible strings which tie your mind and actions and makes you dance. It even creates who you are, the false you, because in fear of it you create the false you to survive in it, to not be attacked and oppressed more by it.

You dance with it so that you are not destroyed.

The possibility of love is the testimony that nothing, including the Matrix can actually stop you from being real,

despite the Matrix you can act anyway.

## **The onset of being in a future where that testimony of love came into existence already,**

*— it has, otherwise you would not be hearing of this concept —*

this not only means that nothing can stop you from being real,

it also means that by looking into this direction of love, participating in this, receiving it,

by receiving it, receiving that gift,

you become aware of this possibility, a possibility of acting despite opposition, despite oppression.

This breaks off the mental fear that keeps your mind and self in bondage from being free, from being the real you.

Being able to demonstrate real love, to see God’s heart and be able to act out of it, instead of acting in the Matrix script,

This possibility, what it does, is *— in part ,—*

it destroys your fear of pain,

and your fear of pain is what feeds your self, your ego,

And when you remove this,

It breaks you out of the power of your web of lies,

And this allows you to look through the kaleidoscope in order to see the whole earth.

The kaleidoscope is the perspective of looking at the world through God’s heart,

The sight is too beautiful and bright for anything else to exist in that tiny telescope.

Such as this way is narrow and there are few who find 

it,

This one tiny sliver of a possibility, if you look through that telescope,

it breaks open your eyes that have been in blindness up to seeing the earth through eyes of love.

## **You can only see through eyes of love.**

If you are not looking through eyes of love, you are looking at a delusion.

Such as this, God is Reality,

God is Love,

Such as this, mans eyes are in blindness, they see a delusion.

God’s eyes are seen through God’s heart,

Look through God’s eyes and you can look at reality,

Look through the eyes of love and you are able to see the real world as it is.

Only through this can you see,

Not because love is sight,

But because man is blind, because our limitation creates blindness. We are not able to see the whole earth through one tiny mind.

The only way to see the whole earth is to find the kaleidoscope and look through it.

While you are looking through it,

it destroys the darkness of your delusion, it pierces the veil, because it’s too bright for darkness, it’s too conscious for ignorance.

Conscious and ignorance are opposites of the same measure, one removes the other.

The removal of blindness is also because the focus of the attention has moved away from self,

And the thoughts that are manifested and created that have to do with the self are no longer created.

Those thoughts create the blindness.

When you look through the eyes of love, you disappear into the ocean,

The world is bigger than you. You disappear.

When you stop looking through the eyes of love, you become bigger again. Blindness covers your eyes.

The self creates our blindness.

Just in the same way that the action of a demonstration of love is a gift which shows a person’s importance,

The sight of love also reveals to you that something exists that is more important than you, more important than your self.

This is what truly removes ignorance, what truly casts away the darkness and reveals light.

The darkness is simply a small view. It is small and in a small view it is dark.

The whole picture is not seen so it is dark, just one dark spot on the big picture.

When you look through the eyes of love, you are aware of something more important than you were before.

All the things you thought were important are no longer important.

Now you’re looking at something important, something that really matters.

Before, the things that were important were the things you thought mattered.

Now those things don’t matter at all.

Before, all kinds of things mattered, fear of judgement and shame and guilt and expectation and your pride and how people will see you, and your flaws mattered, and your weaknesses mattered, your fears mattered so much,

but they disappear instantly in the face of something that matters.

> *— It is the same as when a person finds out someone is in love with them,*
> 
> 
> *They dance and sing and they don’t care what people think.*
> 

## **What matters has changed.**

Before, being embarrassed in public was important.

But now there is something actually important.

How is it important at all if you are embarrassed in public? People are embarrassed all the time,

And people judge you for anything all the time anyway no matter what you do.

That only mattered because there wasn’t anything more important to worry about.

*— Even embarrassment can demonstrate love, seeing one act for you despite their embarrassment.*

## **What the most important thing is, that changes what you are going to worry about.**

Concern changes when what is important changes,

And the concern changes from sort of limited imaginings,

To real end-of-the-line considerations.

You are drowning to your death.

My fear of my phone getting wet is no longer important.

Before, if I lose my phone, it will be a great problem, my boss won’t be able to contact me I won’t be able to access my bank account my whole world will end if I lose my phone.

But now suddenly who cares about the phone. It doesn’t actually matter. It never actually mattered. It’s a device. It’s actually, legitimately quite worthless.

Your life on the other hand is priceless, it cannot be replaced like my cell phone. It cannot be rebuilt. I cannot rebuild you if you break.

My concern has not disappeared, it is now just no longer on my phone. I’m not concerned about getting wet.

Now the concern is that if I’m not fast enough, if I don’t swim past my normal speed and limits, I may not be able to reach you.

This is to have a concern for God. A concern of God. A fear of God.

My concerns have changed from what I thought was concerning,

My concerns have now changed to the things God thinks are concerning,

what the eyes of love are concerned with.

The eyes of love are not concerned about the smell of the man with no shoes. The eyes of love are concerned with his suffering.

I do not fear the man’s smell getting on me.

I am concerned for him.

The eyes of love I have just described are what Man calls Courage.

> *‘The secret of Happiness is Freedom, and the secret of Freedom, Courage.’*
> 
> 
> *— Thucydides*
> 

Love is Mattering.

Love is Valuable.

Love is Unexpected.

Love is Real.

Love is Character.

Love Can Break the Matrix.

Love is Freedom.

Love is Freedom because Love gives you the Courage to act despite the concerns of the Matrix.

Thanks for Reading.

## **Additional Reading:**

— *I believe that fear and concern have the same meaning in regards to fear of God,
To fear the Lord.
How greatly concerned am I if God were to tell me I was supposed to help that man.*

*And is that really god? God or not,
How greatly concerned am I if I know in my heart that I was supposed to help that man.
This becomes real when you begin to know his heart and hear his voice through this heart.*

*Then you fear the Lord, are concerned with his concerns,
But worse, more heartbreaking,
Is that when you can hear his voice,
When you can hear his heart,*

*There is no question of if you did what he asked you to or not. There is no question. You feel it because you feel the pain of it. The pain of it is like heartbreak, something terrible, like crying, like a kind of agony.*

*This is not your crying, this is god crying and you are hearing him crying.*

*At that point, that is what it means to fear the Lord. To fear the Lord is to not want to run from the directions he has put into your heart.
This experience is comparable to experiencing light, and pulling away from or going towards the intensity of it.*

## **Additional Reading:**

— *Comparisons of Heart*

*When I say God’s heart I do not man’s heart of compassion, though these are comparable.
What I write on this from this line on is in regards to person experience with this.*

*Man’s heart of compassion can see people in suffering. This heart is a red heart, a bleeding heart. It can be healthy, strong, like a rose bush with thorns. It can give out great compassion. It can open up to reach and value many in suffering. It is limited to man’s strength.*

*This is not the same as God’s heart. I am not really comparing these, these are just two different dimensions of experience. I have written about this before and this is well understood in the Christian world.*

*If you are aware of the holy spirit, this is like having eyes to God’s heart. It is not personal, it is as though god can choose you to be his hand if you are in a certain place.
What happens is it is said god “puts someone on your heart”.*

*This is just like man’s compassion when his heart is open and he sees someone in suffering.*

*The first difference is details aren’t necessary. God can highlight a person to you before they have come into physical view of you. He can also highlight someone before you know what is wrong with them.
He can also reveal to you what is wrong with them even if it is not visible.
He can also reveal more information through your intuition.*

## ***Between the red heart and this, these experiences are different.***

*God’s heart is experienced in your spirit as light, and the person highlighted is highlighted as though light were pointing to them, like a spotlight.
This is what I meant when I said to fear the Lord was to not want to pull away from, go in a direction opposite of his heart,
It is like you see and feel the highlight on that person, and you could go to it or pull away from it.*

*You are not forced to,
And your own mind can still give you doubts.*

*This is when you can fear the mind of man [literally your mind] or fear the mind of God.
It is usually not tragic if you miss the opportunity,
But usually the highlighted person is getting attacked by darkness on a level that they are not used to, and they are at the end of their rope.*

*— The last comparison is that the red heart of compassion is always available. God’s heart is more present on a day that he is blowing in a fresh wind into reality, there are days when God is moving and active, and there are days when the wind is still and he is deeply at rest. When things are happening, that is usually when the fresh wind of Spirit is at work.*

May you find Love, Freedom, Light, Life, and the Connection you seek,

and may God, angels, and the mind of Peace be with you.