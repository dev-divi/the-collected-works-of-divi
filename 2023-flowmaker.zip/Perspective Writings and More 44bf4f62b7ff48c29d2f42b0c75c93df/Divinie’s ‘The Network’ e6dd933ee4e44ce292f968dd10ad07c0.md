# Divinie’s ‘The Network’

In the physical world, we see places to go and things to do.
In a metaphysical world, we come closer and nearer to the relationships, the bonds, the connections we have in our network.
How can you view this as so?

This is easy to do. The next time you are in public, close your eyes.
Sense how all other voices in this world come near to you for a while, then they drift out of view.
Like echoes in a vast silence, you hear a voice for a short time before it goes far enough away to vanish.

There are voices that float by that you will never hear again, and other voices you orbit frequently, they center around your orbit and come close, then drift away again. In an intimate relationship, a voice might come so close that it speaks directly into your ear. Finally, the voices closest to you are those you repeat in your head.

If you imagine reality in this way, you can see that this entire world exists within your consciousness, that all voices exist within your consciousness, and whether you hear those voices or not depends on how far out you go. Your vine, your network, is not your city, it is not your neighborhood, it is the entire earth,
it is only that you have not connected with every part of your network,
nor are you supposed to. 

The master gardener connects to good connections and removes bad connections.