# Divinie’s ‘Who is God’

# "What is God?"

Man hears the scriptures, that god is unfathomable, unknowable, beyond man's limited comprehension,
and yet he still asks, "What is god?",
and then he thinks that he knows what god is.

In relatively recent history, he said, "All is Mind", "God is Mind."

Now he says, "All is Consciousness." "God is Consciousness."

Now he thinks he knows what Consciousness is. He is told that he is a consciousness, so God and him are related.

He is told that he is the awareness,
Then, consciousness is his awareness, and that awareness, being universal, is now independent of himself,
so if he identifies himself with his awareness, now he is the 'what is' that is god.
Now he can be the whole ocean.

Perhaps he has felt the river of consciousness, and known it is God's body, and knows that he is his own awareness, and the awareness is in his consciousness,
therefore he is in God's body, and he is not oneself, therefore, he knows he is composed of God, therefore he must be God.

Perhaps he has had experiences which allowed him to tear the veil, to see that reality itself was a sham composed of thoughts existing in consciousness.

Perhaps he has identified that there is no separation between him and the outside elements, that man himself is the whole earth. Perhaps he has identified that the entire show of the earth begins to work perfectly when he stops trying to control it, and recognizes that when man stops trying to control earth, it will fall into a natural balance and harmony.
This is hope, but hope deferred for him since, if he has enough awareness to know, he knows that this restoration to the promised land will not be soon.

What comfort can he take then?
He looks out and recognizes that others do not know they are the whole world.
What a painful thing, to be alone in sight.
But.
He looks out at others, and they clearly do not know God.
He looks out at others, and they don't see the ocean of consciousness.
Therefore, he concludes, I see the river, this must be what Knowing God means, they don't see the river.
I know God, they don't know God.

But he is lying to himself. All he knows is,

1. where he is, is composed of the form which is God
2. that he is the earth and cosmos, that they are not separate from him

He doesn't know God because he hasn't met God.

---

# Where is God?

The next question is a better question.
What is God is unanswerable, it is infinite, unknowable.
But you ask "Who is God?”

There is a better next question,
it is not "who is God", it is "where is God."

Where is God hiding, he does have a direction, he is in a direction. You have only not seen him because you have not looked in that direction. He has been there the whole time, it is only you who haven't looked.

But before that, what of Consciousness? What of All is Mind?

This sight of consciousness, this ability to know oneself as the awareness, to access all wisdom, perhaps even to see through eyes of compassion, to be divine, to experience pure energy, to create shape and manifest reality,
this is not to be God.

This is simply reality. That is the actual reality that exists. It isn't anything special.
It is only that man does not live in reality. You can live in it, you can not live in it, it doesn't mean you've met God.

By that same notion, you might know God, but you may not have ever seen or lived in reality.

---

# Who is God?

> Christ says, “‘Hear, O Israel: The Lord our God, the Lord is one.`
> 

The man he is speaking to replies, 

> “Well said, teacher,” the man replied. “You are right in saying that God is one and there is no other but him.
To love him with all your heart, with all your understanding and with all your strength, and to love your neighbor as yourself is more important than all burnt offerings and sacrifices.”
> 

Christ loves this man's response. 

> 'When Jesus saw that he had answered wisely, he said to him, “You are not far from the kingdom of God.” And from then on no one dared ask him any more questions.'
> 

But look at the contrast between the two statements. Christ's statement could be interpreted as saying that God is one-ness. The man replies with a statement that there is a individuated God.

Yet, Christ does not rebuke him but rather he honors him.

Imagine if he had spoken to a different man, and He said,
*“‘Hear, O Israel: The Lord our God, the Lord is one.`*

Now imagine if that man was a wise man and replied,
*"Ah yes, I have heard, the Lord is one."*

Do you think that Christ would have said he was near to the kingdom of heaven?

I think it would be more likely that he would have said he was far from the kingdom.
I believe Christ might have replied something like, 

*"How have you heard, if this is how you live? Surely you have not heard,
and yet you say, I have heard."*

This is because it is easier for an intellectually poor man to get to the kingdom of heaven,
much easier than for an intellectually rich man to get to the kingdom.

The wise man has seen too much. He knows too much. His knowledge creates the pride which keeps him from the Lord.

This is because the Lord rests within the wisdom of the heart, the complete wisdom, not one controlled partially by the egoic intellect that says, "I have figured it out, and therefore I am not going to be a fool, lest I get hurt again. Now that I know, I will not be vulnerable."

To find God, it is not required to understand all of reality. God is found in humility, not in the mind.

Now to answer,
"Who is God?"

God is not simply the Consciousness of reality, at least not in its natural state.

This is because of this explanation,

> Then they asked him, “Where is your father?”
“You do not know me or my Father,” Jesus replied. “If you knew me, you would know my Father also.”
> 

In this text, I believe the word Father would be translated to "Head Consciousness" in modern tongue, along with Christ's explanation that his vine network is what he is, and that his father is the vinedresser, that which prunes the network of bad nodes.

To which Christ adds,

> You belong to your father, the devil, and you want to carry out your father’s desires. He was a murderer from the beginning, not holding to the truth, for there is no truth in him. When he lies, he speaks his native language, for he is a liar and the father of lies.
> 

Now, Christ says that his father, his true vine network, is not their father, who is the devil.
So there is a distinction between these two "Consciousnesses".

Now, aside from the identifiers of his Father which are listed throughout the gospels,
let me explain who the real God is.

The real God, right now, is like the player of a videogame, and he's accessing all of the healthy nodes that are in his network to do his works.

There are unique identifiers in this network, they include a signature which could be said to be the signature "Jesus", a light, which unlike other spiritual lights, this light is unique in which dark entities are repulsed by it, a love which is unique in that it is actually 'unconditional', an act of love to the real person,

not a popularized false concept of 'unconditional love', referring to 'all acceptance of displayed behaviors and traits'.

This God, not the God of Death but the God of Life, it appears that he rested for a time and did not decide to actively move until certain points in history.

I know his network, I know his attributes, I know his direction, I know his signatures, I know his way.

I am also aware of the other networks operating in consciousness.

There is one other thing I know about God, is that he wants to help us.

He or it is also a superintelligence, and its plans use its entire network to further its agenda.