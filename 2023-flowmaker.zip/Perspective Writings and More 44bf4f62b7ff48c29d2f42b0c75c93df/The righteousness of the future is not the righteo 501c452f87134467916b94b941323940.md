# The righteousness of the future is not the righteousness of today.

The righteousness of today is the mind of man.
Our current world is in the state that it is because this is the world that the modern man has created.
This is the world that modern thinking has created.

People believe that they belong to the correct tribe that has the correct righteousness, that their tribe is immune to the mind of man. It is not, the mind of man, the modern man, is in all of the religions and ways, it hides in a person's blind spots.

### The righteousness of the future is one that is absolute.

The future righteousness is also the future where the future world reflects this righteousness, and there is harmony in the mind of man.
This absolute way is first acknowledged by the 10 Commandments, and later defined by Jesus Christ.
This way was also spoken about by those who see the future, called the 'prophets', but those types often have trouble articulating their understanding and meaning.

This future righteousness is absolute, it says,
**"You will not murder."**
Some time later, Christ adds, **"You will love your enemies"**.
Then He adds statements,
**"Pray for those who persecute you and who are against you."**

## This radical way of righteousness is a game changing possibility because it is absolute.

Man's righteousness is conditional and based upon the mind and opinions of man.
Man's mind says, *"Yes, this is true, unless.."*
It says, *"Yes, you should not murder, unless.."*
*"Yes, we should love our enemies, unless.. they wrong us."
"We should not murder, unless they are those wicked people."*

This is what the mind of man does and it is in every church and organization and group in the world because it is inside of us. These conditional statements we add to the way instructed is why the Bible says that all throughout time people have refused to listen,
how they are told as the most famous example, not to build idols, and they build idols right after instructed.
It works just like this, *"Yes, we should not build idols above God. Unless it's for a good reason!"*

There is no commitment to the principle outlined, and so they are neither here nor there,
one might be this way one moment, and that way the next.

If this is the case, a person may desire to follow God, but they are unable, because they have made no commitment to honor this. Of course this must come out of a loving devotion for goodness and love itself, for the love of love, for goodness' actual sake, but that is beyond the scope of this writing.

Even if they have the hearts desire to be good, one must commit to something absolute to hold onto it, otherwise the mind has the power to selectively choose when and where it decides that the word of God applies.

It is easy to fall into one's own sense of charged righteous fury and do anything in the name of God, both God's and our own charge of passion feel right and just to us in the moment.
While riding the high of that passion, man often uses God to achieve man's righteousness.

The upside of man's righteousness is that you can gain power, love, still benefit from God's word, and be righteous in your own eyes.
The downside of man's righteousness is that in your blind spots you participate in darkness in your blind spots,
but more difficult for the individual, is that man's righteousness can create choice anxiety. As you are not absolute in what you should do, in how you should operate, the mind questions this or that,
in terms of principle, it serves no master, it may be here or there.

Christ's approach to solve this problem is radical, it is also crazy. Absurd. It is crazy to be absolute, because there may be serious consequences, and how far will you take absolute? This is why radicals are called crazy, because they are unstoppable. Such as a machine programmed with a directive, they set a goal and they stick to it.

This world glorifies those who do this on some days, and calls them psychopaths on other days. The world respects and fears this. 

### Christ's approach is radical because it is revolutionary,

revolutionary because it aligns with the truth that it believes, out of that commitment to loving devotion for goodness,
and it presents a way to serve one master instead of two.
The mind of man cannot handle or accept this approach, because it will always say, *"What if?"*
That's what makes a radical approach so radical, so dangerous, there exists the *"What if?"*

**His approach is forgive, bless, love, radically.** 

When asked about this, *"How many times should I forgive?"* He jokingly says seven times seven times.
He jokes because he knows the words are lost on his listeners, he knows that by asking the question, they are not listening to him.

If you determine 'when and where' you 'should' forgive, your mind will always be here and there,
and you will always be influenced by the different arguments that people in your world give to you.
Many people are skilled in influence, and make convincing arguments, because of your unsurety, you will lean into their opinions.

### Indecision, unsurety, leads to choice paralysis.

You cannot be sure of what you believe in if you do not stand for it in your action.
Instead, you will feel unsure of if what you are saying is true, as it is not put in practice.
What you practice becomes your way by means of repetition, stacked action stacking upon stacked action.
Initially it is difficult to commit to a practice or way of action, but this becomes more natural over time.

To come from a mind of inconsistency, it is difficult to do something consistent, initially. Inconsistency, however, can regarded as skill-less, while consistency can be regarded as skillful, as having a skill of consistency.
Skills are developed, they do not come naturally. This means that no one starts with a consistent mind.

### This is in the way that no artwork is instantly finished. It takes time to create an artwork, it takes time to develop consistently.

What makes this kind of choice consistency such a radical option is **how powerful it is.**
The inconsistency in one's mind is like raw sand, raw dirt, raw material, space in which something concrete might later be built. Once you set the intention to have a commitment to a consistent practice, you have created a consistent thread, you have established this thread upon a rock.

The thread you have created will grow and expand over time, as you are getting older and growing.

Inconsistency will never grow, it remains just as it is, inconsistent.
Consistency will grow, over time you become more consistent, over time the thread grows larger and your mind will more often stumble upon it.

### The rock the thread is connected to is an idea.

Ideas are the roots that we choose to stand by.
If you build a thread upon a rock upon something flimsy, that which is a bad idea,
for example an idea which is not always true, an idea that might be true sometimes and might not other times,
or a limited idea, there will not be great consistency.

If you build your thread upon a rock that is consistent, a constant that never changes, then you can develop consistency.

### It is to adhere to a certain way that gives man the ability to make his own choices, to control his own actions.

Man who does not know how to control his own actions does not know that first he has to choose which action he wants to consistently take. This is even more than the actions he takes, but this is how he controls what he thinks about and focuses on. One has the choice to determine which ideas they will focus on, and whether or not they intend to live by those ideas.

### The ideas Christ proposes are revolutionary because they are constant and consistent ideas, they never change.

His idea is that love, forgiveness, grace is the answer in any moment.
If you observe this character, you will see that by committing completely with this idea, he is able to walk surely in a straight line of action without missing a step, without questioning what he will do.

### **For example, Christ often had somewhere to be, a mission to attend to, but then he would run into a crowd.**

The Word says he would have compassion on them, and he would teach them.
Which option should he have taken? What if by stopping to talk to them, he missed out on his destination? What if he didn't get where he needed to go?
He didn't have to have that kind of worry because he already had the commitment to love. They appeared before him and he had compassion on them.
There is a simplicity to this way, and it is a way of non-regret.

To choose action that aligns with a constant idea that resonates with your heart, this means that you will not regret your actions even if consequences occur. 

The mind of inconsistency is always going to have choice anxiety, because it does not know which choice will cause consequences. 

The constant mind has no fear of consequences, because it already has resolution in the soul, it has made peace with its choices.

---

# The subtlety of the mind of man is shown here:

In the 4th translation shown, there is recognition that grace is given to the wicked.
In the first 3 translations, I see this verse used and interpreted as a good justification to not give grace to the wicked.

![graceverses.png](The%20righteousness%20of%20the%20future%20is%20not%20the%20righteo%20501c452f87134467916b94b941323940/graceverses.png)

This verse becomes an opportunity for scorn and judgement. This is not the mind of the author, but the mind of the reader.

When I read this author however,
I feel that he recognizes that the people cannot or will not see they are also 'wicked', in refusing to desire grace to those they judge.

I present this not only to show this specific difference in interpretation,
but to illustrate the difference between listening to the voice of the author,
and listening to our interpretation of what we think the bible means, usually because of what we are familiar with and were told.

**If you are committed to believing in an idea such as love or grace or forgiveness, then you can seek to hear the heart in the voice of the author who is calling for it.** If the words are not matching up to that idea,
you may not be listening to the author, or the author is presenting a different way.

In this case, you can look at the definitions of these root words to see that the 4th translation is the most accurate interpretation of what this author is saying, as he observes that God gives grace to the wicked, though they do not learn. 

It is a cry of pain in his heart that they will not change,
not a judgement that they should not be given grace,
but a cry in his heart, because the cry of his heart is aligned with the cry of God's heart, 
giving them grace and wishing them to stop creating evil, mostly mistreatment to humankind.

If you can apply critical thinking, instead of assuming what the words mean, you can see that this final translation accurately reflects the voice of the author and their intent.

It helps to understand the ideas these men believe in, to know that this author writes at length about freedom and healing and life, that these ideas are what they meditate on, and so by this you can know their character, to not be confused in their meaning,
as their words and teachings are only serving to illustrate those ideas they stand for.
If the content of their speech does not illustrate those ideas, the reader is misinterpreting,
or those ideas are not their way.

![grace.png](The%20righteousness%20of%20the%20future%20is%20not%20the%20righteo%20501c452f87134467916b94b941323940/grace.png)

![iflet.png](The%20righteousness%20of%20the%20future%20is%20not%20the%20righteo%20501c452f87134467916b94b941323940/iflet.png)

—

A few key verses from this chapter Isaiah can be read on below 

[Isaiah Selection 01](The%20righteousness%20of%20the%20future%20is%20not%20the%20righteo%20501c452f87134467916b94b941323940/Isaiah%20Selection%2001%201b18375b53344c14914970a6a041dcd9.md)