# Tonight — The Shift in Human Consciousness

Some days ago, there was a day of darkness. The vibe of the night was not the same as other nights, all of the freaks in the city came out that night, rejoicing in that darkness.

On that day, there was a person, their darkness was exposed to the world, and they lost their career and their housing in one strike.
A combination of self-sabotage, guilt, shame, and sins caused their world to crumble for that day,
when their was on the verge of career advancement and opportunity.
What exactly went down?

This day was the day before the Jewish Passover celebrations began.
This and other events when masses of people are focused on light, health, prosperity,
these periods of light are preceded by a night of darkness that comes before it.
Darkness always gets darkest before the light comes, and evil waits and plans for this day to strike,
just as good waits and plans for the day to strike after.

What is this darkness?
Darkness is an abstraction for information that humans use to identify a variable in the patterns of human life.
We use terms like darkness, light, unconscious, conscious, as abstractions to point to and track the commonalities in the human drama that has been repeating for millennia.

This is a story that has always played out the same, will always play out the same, millions of times it has played out and that is why we are able to create fictional stories and parables that represent the way the stories in reality play out.

There are key happenings in this story, but they are not what you expect until you investigate them.

What is the intention of darkness, what is its plan, and what is its goal?
Why is there self-sabotage?

The plan of darkness is consistently the same. The light side of you is attempting progress into the story of your life,
It has a case of evidence built up for you,

Light has a case of evidence built up for you, your inherent qualities of goodness, the positive story of your life.
Darkness is also actively building a case against you, it knows that all secrets and mistakes you hide will be exposed to the light and its plan is to take you out at the point of maximum effectiveness, to get the highest possible chances at taking you out completely when it strikes.
It looks for your faults, mistakes, weaknesses, and sins

And it plans to present the case to why you should not continue your journey.

You and other people are spectators and participants in this story,
you and other people provide spoken testimony on that story.
Is the person good or bad?
You are the person who will take the majority vote, and the world of others around you add to that testimony.

The motivation for darkness and the motivation for light are not to create good or evil,
The intention of these forces in this story revolve around your actual Destiny.

Light forces are at work to aid you in moving forward in your destiny,
Dark forces are at work to prevent that destiny from coming to pass.

It is ultimately you who continues to move into that destiny despite the strike that is certain to come in the day of darkness.

When the day comes and a plan strikes against a person,
You must be very careful not to identify with or be carried away into the story too much,

Because there exists a phenomenon that is described as this,
As you judge, you will be judged.
This is often interpreted as a spiritual concept,
but it is not,
it is a matter of the way the story plays out in life.

What it means is this,
When you judge ruling against someone pursuing their destiny,

When the day of darkness comes to try to stop your own destiny,
you will be judged to the measure that you judged someone else's pursuit of their destiny.

This is always a matter of destiny.
In life, in judgement, you are either choosing to support or not support a person's destiny from coming to pass,

you are either passing a sentence to them and yourself of life, or death.

To the harshness you determined a person's destiny should not come to pass,
this is the harshness you determine your own destiny should not come to pass.

This is not spiritual, this is simply the way the human drama of life plays itself out,
the darkness waits and plays its best hand, this can be noticed in  self-sabotage,
and the light waits to play a miracle hand if you survive the night of darkness.

The system is set up so that any sins you have hiding will be removed from you before the light comes.

Darkness attempts to work that system as best it can to try to take you out for the count when this inevitable phenomenon occurs.
All those who work with darkness will also take their best shots at you on this day.

If you have any concern for your own life, you are careful and mindful of how you judge, knowing that the day of your own dark night in your personal drama is coming,
and if you want to survive that night,
wisdom says that you take care in whether you aid or hinder others in surviving their dark night.

I’ve just learned that this is not a normal pass-over,
Tonight the largest number of people likely in history are going to take communion at the same time

This is a mass ritual, and in any mass ritual, good or evil, a mass agreement of human consciousnesses in union can shift the collective consciousness instantly. 
This is historically significant.