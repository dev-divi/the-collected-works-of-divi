# Divinie’s ‘Who is the Father?’

[ written to a religious man with an eye of judgement ]

Jesus’ god saw him and others in a loving light. 

He said their god was a god of death, and his was of life. All mentions of his father were loving. 

The Word says that God plans to destroy death, that plan is carried out through his love. 

One part of this is through the end of the eye of judgement. 

Jesus commands that we end this cycle of judgement, of who is sinning,

and it is hard for us to learn to do that, but we are all learning to. As you judge so you are judged, the sooner you begin to soften your gaze, the sooner your own self judgement will cease being a torment to you.
We create our own torment of hell and invite demons in by our judgement,
it becomes less harsh when we learn how to become  compassionate towards ourselves, but first you have to learn compassion to others.

A god who sees humans in a non-compassionate way and wants to punish them is not the god Christ talks about.

Christ's God is "Abba, Abba"
Affectionately like Dadda, Dadda, his father is a loving father, who is for him and not against him.

This is the Father of Isaiah, David, and Jesus. 

My father too is for me and not against me, and he will wait all throughout history until man open his ears to hear and his heart of stone opens.
Man is Jerusalem, but god will build a new Jerusalem when man opens the gates.

Man speaks of God from the mind,
Trusting and hoping in ideas,
But God is waiting for man to listen to Him through the ears of compassion, in the heart,
As he has been calling and crying for his people to do for thousands of years.

You can feel his heart expressed when Christ embraces Mary Magdalene and says, "there is no one left to judge you." This is when the compassion of his father's heart is felt. If you look through this enough you will see through his eyes and it will awaken you. 

First you have to stop listening with your ears and gain ears to hear. 

Know that your father never turns on you when you fall into darkness, he always intends to help you, support you, as you are his child. He has the power to have compassion and kindness toward anyone, but you especially are his favorite, he is always waiting for you, overflowing with endless love for you.

The serpent and liar attempts to convince us that God abandons us or has turned away from us. This is one of the devil's main tactics to get us to fall out of righteousness.

There is a way to experience God's love and it is through walking through his grace, you may fall into his grace. This gives you peace and power and authority, it is supernatural and life changing. People resonate to you and gravitate to you, good and miraculous things happen, and you feel the oneness of the father. This is waiting for you to step into, you start walking in grace and it will activate in your life, the father will use you as one of his vessels and send his light through you to others.

You want to reach others but they don't respond to you, you want to help others to honor God but don't know how, pursue grace and walk in grace and god may use you.