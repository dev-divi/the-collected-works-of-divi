# Deeper Into The Shadow

This writing is not for those who have not deeply explored the inner self.

I have spent a lot of time in my shadow.
This is what caused me to grow 'spiritually powerful', or 'more conscious', or to 'know myself more'.
As the shadow grows, the light also grows.

In the shadow, we recharge. This is our deeper state, where our real self/ego
that has grown over the years is always resting.
All that is in shadow is how and what we would be without an outside influence, without our usual restrictions and limitations, imposed on us
by the demands of an outside world.
In shadow is the rest from the conscious self's unending desire to strive
for more, to be different than it believes it is, to push itself to follow the ways its beliefs say that it ought to be,
to be as strong as it thinks it should be, to have the personality it thinks it should have, to meet the expectations imposed upon it.

The conscious self becomes tired and stressed and takes no rest,
it does not stop to recharge,
but every person must recharge eventually,
and so every person falls into their shadow.
Most people recharge for short amounts of time in their shadow as they listen to certain music and watch movies, during which time they do not realize they have let go of the striving of the conscious self and are taking that time to recharge.
As they are not recharging enough with these suboptimal activities,
the pressure builds until their shadow overtakes them,
and they are consumed with their hidden desires,
recharging while letting go into pornography addiction, sex addiction, food addiction, drug addiction, binging addictions.
In this state, they are granted a temporary break from their stress of their conscious self,
but when it takes back control,
they have to deal with the guilt and pain their conscious self will judge them for in their self-destructive behaviors.

In the shadow state are hidden desires, as well as repressed creative faculties and unused sources of mental energy. This is the limitless flowing creative state. In shadow is the version of oneself that is a master of what they do, because the usual fears and resistances are not present.

The shadow is not evil, but in shadow, all evils can grow, all negative vices to pain can be fed.

If one spends time in their shadow without engaging in their self-destructive impulses, desires and behaviors,
then they grow in energy, they greatly recharge, they find deep relaxation and rest.
This would be meditating on the shadow self.

The problem is that because people have not spent time in their shadow,
it is large, uncontrolled, dangerous, unstable, it is a monster of great size, an untamed beast. This is why if it gains control, the person immediately is consumed by their impulses and addictive behaviors.

For most people, this existence of human life is hell, and they are not even aware of it. In their conscious self, they are stressed and overwhelmed,
in their shadow self, they are helpless against destructive behavior.
When they swing back to into their conscious self, they now have guilt and feel like hiding from others. They have no real control over their life, and are slaves to the unending desires of the conscious and shadow self.

To meditate on the shadow self in one regard would be to practice being still within it and not engaging in destructive behaviors,
in another regard would be to be within it and participate in constructive behaviors such as the arts.

The Shadow is naturally avoided as within it lies fears, toxic feelings, toxic beliefs, wounds, inner demons and torments, undesirable thoughts.

Most people that choose to do shadow work intend to clear out some of these undesirables from their person with different methods and techniques. Therapy is considered to be shadow work.

The main concept of the shadow was the idea of integration between the shadow and conscious self in order to become whole.

Most attempts of this have failed, and this has driven many mad in the attempt.
In less severe cases, people find that shadow work often only results in more problems, that never ending problems arise to be fix and they experience even more darkness in their lives than they started with as a result.

Consider why this might be so, the conscious self picks and chooses what it should be and what it should not be, as it always does,
and then shadow work is attempted to continue to further the conscious self's goal to be what it should be and destroy what it should not be.

This is the same issue of spiritual work in general, the issue in which a person consciously thinks they want to be good,
but in reality they are trying to use spirituality or a religion to remove parts from themselves that they do not like so that they can be the way they think they should be. It doesn't work.

---

My experience of my shadow self has just changed.

I have spent a lot of time in my life meditating in shadow, and the experience has largely been that I recharge, and pursue the creative,
but I am hiding from light, and while hiding, my pains and self-delusions have had room to grow.

Much of my experience in shadow was also overwhelming from the feeling of overflowing unrepressed creative and spiritual power.

In the journey of my conscious self, having found no desires that satisfied me, and getting tired of desires,
choosing to intend to let go of desires,

this has extended to include my spiritual desires.

I stopped feeding my desire for spiritual power in my conscious self,
and at this point I am no longer feeding the desire for spiritual power in my shadow self,
and so I am no longer feeling overwhelmed while I am in shadow.

Having stopped pursuing that, I have recognized that while meditating in shadow, I can still keep the same compassionate awareness I intend in my conscious self as an intention in my shadow.
I can also still keep the intention to connect to love in my shadow.

This has allowed me to recognize that the 'light' that is usually disconnected while in shadow is the light of connection, of love, and the warmth and fire of compassion.

If **conscious intentions of compassion and love** are present while in shadow, it is still possible to recharge in shadow,
without pains and evils and self-delusions growing, as they do while in separation from light.
This allows rest from the conscious self without growing darkness/evil/pains.

This also allows the shadow to exist as it is, without the pursuit of
'reconciliation' and 'integration' of the shadow and conscious selves, the pursuit that is said to drive men to madness.
It has been modeled that it is impossible to reconcile these opposites, and that the attempt to do so is misguided, as it does not understand that night cannot merge with day.

Instead of attempting to 'fix' oneself by an attempt to 'reconcile the shadow' as has been modeled by Jungian psychology,
the possibility of conscious intention to bring compassion and love into the unconscious shadow state brings a fresh meaning to classic concepts of
*'lighting up the darkness',
'a fire that burns in the darkness',
'lighting a candle in an inner temple'*.

From a modern American perspective, instead of only having the subconscious fed by large mass media advertisements and propaganda that you do not choose,
there is the possibility of feeding the subconscious with that which you can choose.

My experience of my shadow self has just changed.

I have spent a lot of time in my life meditating in shadow, and the experience has largely been that I recharge, and pursue the creative,

but I am hiding from light, and while hiding, my pains and self-delusions have had room to grow.

Much of my experience in shadow was also overwhelming from the feeling of overflowing unrepressed creative and spiritual power.

In the journey of my conscious self, having found no desires that satisfied me, and getting tired of desires,

choosing to intend to let go of desires,

this has extended to include my spiritual desires.

I stopped feeding my desire for spiritual power in my conscious self,

and at this point I am no longer feeding the desire for spiritual power in my shadow self,

and so I am no longer feeling overwhelmed while I am in shadow.

Having stopped pursuing that, I have recognized that while meditating in shadow, I can still keep the same compassionate awareness I intend in my conscious self as an intention in my shadow.

I can also still keep the intention to connect to love in my shadow.

This has allowed me to recognize that the 'light' that is usually disconnected while in shadow is the light of connection, of love, and the warmth and fire of compassion.

If conscious intentions of compassion and love are present while in shadow, it is still possible to recharge in shadow,

without pains and evils and self-delusions growing, as they do while in separation from light.

This allows rest from the conscious self without growing darkness.

This also allows the shadow to exist as it is, without the pursuit of

'reconciliation' and 'integration' of the shadow and conscious selves that is said to drive men to madness.

It has been modeled that it is impossible to reconcile these opposites and that the attempt to do so is misguided, as it does not understand that night cannot merge with day.

Instead of attempting to 'fix' oneself by an attempt to 'reconcile the shadow' as has been modeled by Jungian psychology,

the possibility of conscious intention to bring compassion and love into the unconscious shadow state brings a fresh meaning to classic concepts of

*'lighting up the darkness',*

*'a fire that burns in the darkness',*

*'lighting a candle in an inner temple'.*

---

From a modern perspective, instead of only having the subconscious fed with bad seeds by large mass media advertisements and propaganda that you do not choose,

there is the possibility of feeding the subconscious with good seeds which you can choose.

In this would be an extrapolation of the wisdom in the parable of the weeds, 

> *“Do you want us to go and pull [the bad seeds] up?”

“‘No, 
because while you are [removing the bad seeds], you may [remove the good seeds] with them. 
Let both grow together until the harvest. 
At that time I will tell the harvesters: 
First collect the [bad crop] to be burned; 
then gather the [good crop] and bring it into my barn.’”*
> 

To simplify this, 

Instead of attempting to remove all of the bad that has been planted in your subconscious, 

it is better to just plant good in your subconscious, 

when the time comes that those planted ideas have finished processing and manifest in your consciousness, 
as you go through ‘phases’ and ‘stages’ of life, 
the good is kept and the bad is discarded, 

as you become the next version of yourself. 

You can look at your life and see how this is true, 

if you look back at previous versions of your self in periods of your life and see that the good was kept and the bad was left behind. You no longer carry the bad parts of your teenage self, but the good parts became a permanent part of you, they were ‘brought into the barn’ of you and kept.