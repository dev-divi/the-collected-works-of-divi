# Getting closer to the real you

### "Set your mind on things above, not of earthly things.”

---

The road to self-discovery, self-inquiry, leads one to answer the question, "Who am I?"
Modern thought has raised up a concept that "you are what you think about."
This is the concept that you define yourself by your thoughts.
This would mean that the answer to "Who am I?" would be, "my thoughts."

Now, surely you can recognize that you cannot just be "your thoughts", since you did not author all of your thoughts and many of them are borrowed.

Then there are only two considerations. Either you are not your thoughts at all,
or some of your thoughts are yours, and some of your thoughts are not yours.
Which thoughts are yours, and which thoughts are borrowed?
Does to have borrowed thoughts which are not yours mean that you are not being yourself?
What does it mean to be, "being yourself?"

If some thoughts are 'more you', and some thoughts are 'less you',
then to think about the thoughts that are 'more you' means that you are being yourself,
and to think about the thoughts that are 'less you' means that you are losing yourself.

Here is the problem. How do you know which thoughts are the real you? How do you even know the real you?

Are you even qualified, from a limited set of information, to determine which is the real you?

Surely you know.

For most people, the thoughts which are "yours" are the ones that you have repeated most frequently and they have become most comfortable, most familiar. This is why you hold tight to your ideas and resist change.

For those on a pathway to discovery, perhaps self-discovery, a person looks for the information that is the most real, the most accurate and verifiable information they can find. This person has questions, they don't want answers, they want *to know*.

Soon they will not associate themselves with the thoughts that are familiar to them, but the thoughts that resonate with a resounding in their hearts,
like an ancient memory being prompted, when they hear the sound, they begin to remember something they have forgotten.
They begin to regain themselves, who they are.
For those, the thoughts that are theirs are the ones that resonate,
and eventually they may come to realize that the reason these thoughts resonate, are because they are the core of oneself, the core of what they know and understand and believe.
This is a part of the light that calls them, the light is also the truth which exists inside of them, which when they see and hear in the world, they say, "I know that sound, I know that voice, I remember this, it is calling to me."

I have found a powerful idea in this,
"Keep your mind on eternal things, not which passes by.."

I began to put this into practice, and I found a phenomenon, a possibility of being.

When I was young, this statement meant that perhaps it was virtuous to think of heavenly things, and so we ought to.
Perhaps it was helpful to look up at heaven and turn our eyes from the destruction of the earth, a sight that might damage us over time.
In any case, the idea was that we might be afforded a temporary distraction if we focused on better things.

This is no longer my interpretation, or at least there is a much greater possibility here.

As I began to focus on the nature and way of all that which is Eternal and Unchanging, I began also to see all that which is temporal and disappearing. It was easy of course to look at others, to watch their focuses and aspirations and moods swing this way and that through the days and weeks.
Eventually I began to notice my own self's temporal nature, and I began to observe all that arose and disappeared in the moment.
I began to disidentify with the temporary nature of my self, I began to disidentify with my self, which is temporary.

As I investigated I came to find this coming down to thoughts, which of my thoughts were of a temporary nature?
Of course I could easily recognize that thoughts of worries and doubts were of a temporary nature, they were fleeting,
such that I would never remember them again. I could easily recognize that limited and meaningless thoughts were fleeting, I would never see them again.

I set the idea that I am an eternal being, and based on this premise, those thoughts were not the real me.

This is when I discovered this understanding, an understanding that without 'thoughts of an eternal nature',
a person has no consistency.
They cannot be a real self, because there is not often a common thread to tie the individual throughout the many changing experiences of life.

This is when I began to understand, things change, life changes, we change, but eternal concepts and thoughts and values and virtues remain as constants.

This is when I began to see that if I lost myself, surely I cannot find myself again, forgetting who I even was,
but if I put my mind on eternal things, then I return to the same place once more, and once more again.

There is still the transient, temporal me, the self that will die
but there is also a constant me, returning each moment and each day of existence, with this human experience.

---

### *The real me,*

*is like a lion sleeping deep down inside of me. He can be roused, he can be stirred up to awaken,
but without reason to act, he will slowly return to a slumber.*

*The lion is roused by a specific sound that it knows, a sound it remembers. When it hears the sound, it begins to awaken,*

*The sound has a tune, it has a meaning, it has a charge, and it is the sound of my real voice, my real meaning.
When I write, I attempt to draw from that sound. I attempt to eat from that electric charge.*

*If there is no charge in the sound of the voice I am writing from, I discard the writing entirely.*

*Here is the discovery, if I hear the sound often, the lion will stay awake. Whether the sound comes from my own voice
or the voice of another, the more often I see it, the more time I will have spent as myself in my life.*

*My temporal self includes the parts of me that are decaying. They are only sustained so long as I continue to reinvoke them and keep them alive.
My real self has quadratic growth, every second spent with that self grows the real me in its virtues and in a resonance with its charge.*

*As I have meditated on these eternal things, one of the closest to me at this time is righteousness,
which evokes a strength and courage from me from whence I do not know where it comes.*