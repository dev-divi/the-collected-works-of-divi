# Divinie’s ‘Desire’

![Untitled](Divinie%E2%80%99s%20%E2%80%98Desire%E2%80%99%207668a835bcbd485e9e1602fa25c327a0/Untitled.png)

It is not mammon itself that creates evil, but the love of mammon that creates evil. 

It is the desire for mammon which creates evil. 

This kind of thought, often related to medieval thought, attempts to identify a root cause for why human beings create evil. 
The end conclusion that philosophers came to was that what we call ‘desire’ is the single identifiable root of the creation of evil. 
This is because if you remove the desire, you remove the creation of evil. 

From a Christian perspective, you could say that demons, dark spirits, and the devil can only use you through a single gateway, the gateway of desire. 

People tend to feel judged when they are condemned for having desire, but it is not having desire which is evil, for you do not create desire and you are not evil. 
It is the feeding into desire which allows space for evil. 

One perspective of evil is that which God does not desire. The things God does not desire are of a measure of evil. The more God does not desire them, the more evil they are. 

You may remember the verses that say that you ought to turn your heart from your own evil desires, over to what God desires.

This ‘medieval’ model does not speak of words with the usual connotations and moral ideas such that we hear these words with in a modern tone and understanding. 
Rather than a moral argument, this model is a human attempt to find the cause of why man creates evil, so that they could attempt to stop creating evil. 

This is difficult for us to understand, and it should be, because this is a human and analytical way to understand a far more curious and deep phenomenon, the phenomenon of human relationships and connection with others. This is like music. This can be understood intuitively from the following thought exercise. 

First, imagine the future consequences of sin, the result of a city or country being completely destroyed by wickedness. 

Now, forget about this “future consequences” perspective. Instead, turn your attention to the now. 

Imagine when you hope to connect with a person, and you hope for an appointment to go well. 

Remember a time when you have thought about saying something to someone, but the words were heavy in your chest, even if you said them, they did not come out right, they did not harmonize in the current moment, they missed the mark. 

This means that they missed the mark of the potential connection you could have had in the present moment. 

In contrast, when you allow a connection to “just happen”, to “unfold”, a moment of connection with another person can be infinitely meaningful. 

This moment of human connection is not unimportant, it is divine, it is as important as anything will ever be. It is to “meet the mark”, a harmonious relationship is to “meet the mark”. 

In contrast again, to miss the mark, is to perhaps have the desire to do something other than allowing the moment to unfold naturally, then exerting your will to act outside of what flows naturally. Then, to speak and say something to that person in the moment would be to actually create disharmony, and ruin the moment which could have been. 

The desire itself did not cause the problem, but to act on the desire created a disharmony in life. 

Thanks for reading.

---

*Perhaps I will return to writing of the perspective of souls gravitating in orbits around each other in moments of silence.*