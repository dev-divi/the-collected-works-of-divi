# The Universe in Starfield in Terms of Role Play Story Building

This text is psychologically intensive and viewer discretion is advised.

End game narrative content is included, if you're a person who has been on the fence for whether you want to get involved in Starfield's universe and you're past the point of caring about spoilers, this may be for you.

I will consider writing a review for Starfield, I have never written a review for a game on Steam.
I do want to capture two parts of my experience of Starfield at this stage of my playthrough.

The first, is the sense of the universe that I am playing in. Starfield's universe's scope is grand, but the story of its inhabitants is small and linear, and I appreciate this. As one gets a grasp of where they are, they can see that there is an established order of human civilization, and then there is free space, outside of the jurisdiction of the mainland. In free space, there are the lawless, and pirates. In Starfield, a faction of the pirates have a size that rivals that of the mainland's forces. This is a design choice in the story that is so critical that I may have significantly disliked this universe more if this had not been the case. I will explain why later.

Compared to The Expanse, Starfield's world builds upon The Expanse. While The Expanse holds the excitement of unstable political factions, Starfield's world is more accommodating to a player, because there is a place for the player to fit into it. Late into The Expanse, there are larger 'pirate-like' threats, but for the most part, the largest threat in The Expanse is the danger of humanity itself.

In Starfield, there is the order, the pirates, and then foreign threats out deep in the universe. This works well, and the last part is reminiscent of other expansive universes such as Star Wars.
This creates that feeling of mystery, that there could be more out there in the stars, which is exactly the sense you want to have when building a universe. You don't know what's out there.

Starfield's universe is more fitting for a player than Star Wars, and I can contrast that directly with Star Wars.
First you have to identify the Player. The first thing we know about the player is that they are not from here, that makes them The Outsider from the start. Next, we know that they probably have a mysterious past.
Next, because they are not from here, they are probably the Solo type. Most importantly, they most likely want to be unconventional and forge their own path.

Now, in Star Wars, the main character is The Protagonist, The Hero. Skywalker has destiny written all over him. He's a long lost prince lost somewhere in the desert, coming back to take his throne. Whether he wants to be or not, he's got royal blood in his veins, Destiny intends for him to sit on that throne. He's not the smartest, but he's got Luck, he's going to have Favor with everyone, he's going to have companions,
he's got it going on.

Then there's Solo. Han Solo. Solo has charm, he's got wit, he's got intelligence, Charisma, he's got mediocre to high-tier skill. He doesn't really have Destiny on his side, he's on the side current of it. He might be traveling with the main pack, but he is a loner, outsider, Solo. There are two important things here, one is that his occupations have accommodated his survival as a soloist, and two, he is small, very small.

This is the issue of having the Solo from Star Wars as the Player. He is inconsequential, small-fry. He's not allied with any large force, he's not a commander, his presence is small. As a role, he can be a smuggler, bounty hunter, sort of gangster.

This issue is an issue of the larger universe, and was evident to me in [Star Wars:] The Old Republic. This issue was also present in the newer Star Wars films, in which a trader divulges that in the Star Wars universe, there's no real morality, that the weapons traders are dealing to both sides, good and bad. Either way, the trader makes money, the whole system is just rigged, on auto-pilot, it's not something the trader can control, and it doesn't matter if they influence it at all.

This was felt to me in The Old Republic. Choosing to be a bounty hunter in that world was cool, because I got a cool ship, but a drifter was inconsequential in the scope of that universe[at least in the early game.]

Yes, the Player can be The Protagonist, but that only goes so far as the main quest, the story of the Hero does not accommodate a life in space, which is what an open-world role playing game such as Starfield is offering. This leads into the second part of my experience, role playing.

A well set up universe for role play of The Soloist is one thing Starfield did pretty right, and its universe would be a lot less inviting if it had not gotten this right. It is most likely that The Player is going to identify with something along the lines of the Bounty Hunter, and the developers of Starfield obviously knew this. The Bounty Hunter is a mercenary up front, but under the surface, he's a poor. He's a street kid doing what pays the bills, and what pays the bills happens to be rough work, rough work includes smuggling, bounty hunting. Bounty hunting is likely the quickest payoff, the most lucrative. The Soloist is smart enough that they've managed to stay on the right side of the law, out of trouble, but they are always close to the line of trouble.

Starfield introducing a United Colonies and a consequential pirate faction from the start, and even a cowboy mercenary faction the Freestar Rangers, this sets up a RP-ing experience for the Solo Player perfectly. The Player can imagine they have done some mercenary work in the past,
and now they are getting involved in these new occupations.
This solves the issue of the Solo guy, with no path or Destiny fitting in and having a large role in his world.

Hitting this mark, Starfield offers the RP experience of the solo bounty hunter, and that of the Protagonist who happens to be a Commander.
Starfield allows you to be either, or both,

you could fly solo on your ship, a drifter in the stars, looking for meaning [in the meaningless 1990's subculture..], while doing odd jobs for ship parts and resources, and a few solo operations. There's a full life in the stars there, going and getting involved with questlines, and then taking your ship out to unsettled planets to have that sense of peace and relief that comes from a vacation home, not an isolation.

Starfield's worlds, at least some of them, are beautiful enough that they capture that sense of awe that you can just chill here for a while.

This is something I struggled with in No Man's Sky, where I would want to settle down in a world, but instead felt that sense of isolation.

Starfield allows the other Sci-Fi dream option, the Star Trek option. You can be the commander of your ship, build the large settlements, go out to address the threats of the unknown.

This all works well, because a person doesn't stay the same all the time, and with the scope of outer space comes the scope of what a person has been and what they will do. Consider Spike in Cowboy Bebop, he is both the Prince and the Solo, he is Skywalker and Han combined. He is legitimately a royal prince, and he is a drifter in his tiny ship adrift in space. He then temporarily intersects with a team of mercenaries, each with their own paths. This is also what the original Star Wars captured, as well as what The Expanse captured. For Spike, it isn't that he was a drifter alone, or a team leader later. Different parts of his story have different lengths. This works well for space Sci-Fi, because who knows how long The Player has been a drifter in space before finding a team, and how long they will drift in space after leaving the team.

In Starfield's world, it's set up so that you can role play as that lone space traveler. 

Later in the game, the characters in this world reveal a terrifying connection to you as The Player, in which The Pilgrim is revealed to be very much like you. He's a traveler. The fact of the matter is, he's just traveled a lot longer than you. In reality, he's your future self. He's the result of a person's exposure to extended isolation and solitude in outer space. He's been everywhere, and done everything, just like you're going to do. Then it's revealed that the Hunter, as the moral-less villainistic adversary, is really just like you too. He's just been doing this thing longer. There's another huge similarity between you and the Hunter too, that makes the two of you just the same. Just like the Player, you know the Hunter has done many things, and you don't know what they are. This is what makes him appear so dangerous, and so villainous. It is also the reflection of the Player. No other character knows how long you've been traveling.

This world's offers you a story of this total isolation in infinite space, where you could be out for lengths of time that no one really knows,
which no person could truly understand. Then it offers that the Pilgrim and the Hunter are a connection to you which completely understand,
whether you like it or not.

### Then it takes it a step further, with the repeat worlds scenario that is introduced by New Game + and interweaves it into the traveler's story.

There is a theme in time travel fiction. This is an idea expressed in Steins Gate; and Steins Gate; 0,
in which once a person has looped through the same events in time travel enough times to realize that their choices have no consequences,

three things happen. The first is the need for variation, they become numb to seeing the same things happen again, and so they desire to see a different outcome of the story. The second is the actions they take in regards to others is non-consequential because they get reset, and this causes the person to experience the loss of their soul. What is happening is they are losing the light of their soul,

because there is no reason to take good or selfless action.

The darkness of the soul, the desire for selfish action, this can only grow, because there is no value in expending the effort to help the others,
they will not remember what you do, so it is not a matter of what you should do, but what you desire to do.
This causes the darkness to grow over the goodness of the soul. Due to the timelessness of time travel, infinity is long.
That darkness has time to grow for however many tens of thousands of years of experience pass by, with no outside force recognizing you.
Next is the third thing that happens, the person doesn't just get desensitized, they go mad. Madness is the result of darkness taking over the soul.
Insanity is the result of the loss of the light of others.

**In addition to meaninglessness with no permanent consequence of choice, a soul swallowed by the darkness of selfish desire, and the resulting madness that comes with that,**
there comes again the complete isolation that comes from no one knowing or understanding your experience, because there is no other person in a time loop who has a memory. This makes you distant, estranged, unrelatable to the memory-less. You can expend the effort to explain that you are in a time loop and remind the other characters each time, but they will never know any better if you say nothing and let it play out on its own.
Steins; Gate 0 at a certain point shows how this is only temporary, because as you gradually become more distant, detached, lost,
eventually the characters will recognize that this is not the same version of you that they know, that you have become an alien, a stranger.

The fact that Starfield decided to capture this in its narrative is kind of unbelievable, because it addresses something about the actual player of videogames that is not ever addressed.
The reality is that you, the Gamer, are the one stuck in that time loop. This is because no one in Skyrim knows how many times you have played Skyrim. Eventually in Skyrim, you will want more variation, different outcomes. It becomes of no consequence to you if you kill a beloved character, when you can simply see them again on the next playthrough.
Starfield shines a light directly on this, not only bringing this into the players narrative, but also forcing you to look at this reflection in The Hunter.

The fact that there are others looping through the game, that you have a connection to those, this creates a completely different feeling in the universe of Starfield than one which you started out as a bounty hunting traveler amongst the stars. The feeling of Starfields universe becomes truly quite terrifying,
that sense of looking into the unknown of a paradox too large for one to comprehend. There is a moment of recognition in which I will never look at Sarah Morgan in the same way again.
This is the experience captured by the classic, Back to the Future, in that we seem to look at people from the past as, sort of, lower than us. When we can see the timeline, the characters in the timeline are less of our friends, now they have become more like robots. It is as though they are now, stupid, more simplistic. It's that they don't *know*. They're just happy creatures, going along with their imagined tiny personal problems, they have no idea of the future, or that there may have been thousands or tens of thousands of repetitions of timelines, they have no idea about larger existential threats,
[such as in the idyllic past of The Avengers, the Avengers are fighting a global threat, aliens are coming to New York, but these Avengers are like children compared to their counterparts in the future, who know of a world where half of the universe was annihilated due to threats outside of the scope of these happy, naive heroes.]
It seems that the future is dark, or at least, the knowing of the future makes characters much, much darker. Sarah Morgan suddenly appears naive.

### Back to considering what Starfield offers as a Sci-Fi Role Playing Game,

Starfield's true strengths and weaknesses do not lay in its expansive, open-world sandbox, but rather in what options are made available to the player. This makes it clear that the developers were asking questions,
*"What do players want?", "What do they want to be able to do in this universe?", "Who do they want to be?"*
That makes me feel almost a bit too catered to, like they're just providing me fan-service, [ I love that you know I want to be Space Batman, but am I really that easy to market to? ]
instead of trying to make a videogame for the purpose of trying to make a good videogame,
but I can live with it right now.

What I don't know, is if I will want to play Starfield after completing the game and looping through it in New Game+ runs.

I intended to finish the campaign, finish the side missions, and drift out among the stars doing odd jobs and building a dream outpost.
Those plans have had a wrench thrown in them after I came to know the mechanics of New Game+.
It was jarring for me to learn that I couldn't take my belongings with me into new playthroughs,
but this right here appears to be one of the developers best choices, maybe even one of the best design choices for a videogame in history.
This is something that adds to a role playing experience, especially to one where the consequence of choices is negated by a looping experience,
in which this choice is hugely consequential and impactful.
Giving a player a sense of impact in their choices is crucial to a game in which you make choices.
This one just fits the narrative and the character unbelievably well.
For a character who has lived countless lives, been countless places, death and rebirth are part of their story. Even more so with the endgame spoiler narrative. What true death is there but the recognition that you cannot take the physical with you, you can only take your experiences with you.
This creates that sense of truly leaving it all behind and venturing again, reborn as a new character.
This really actually hits, because my main motivation for playing was to,
A. Go do things and acquire things
B. Put things in ship
C. Go home to base and offload things to base.
I already spent quite a lot of time on that. I've spent a lot of time simply just walking, overencumbered, long distances, just to sell a few things to vendors to make a few creds.
The idea of just starting over from that makes me question my motivation for even playing the game at all,
and I've even considered not playing the game at all, since it will be difficult for me to get that sense of completion of doing all there is to do, completing a whole quest log. I don't see myself completing every little mini-quest on NG+10. I also don't want a whole quest log full of unfinished quests in a world that I haven't done anything in.

It's kind of exciting too. Maybe I'll just avoid a lot of quests. Maybe I'll join the Freestar Rangers. Maybe some of the people on the Collector's ship I murdered actually had questlines to offer, they had full names after all.
There's a feeling there that I could still carve out my characters story in that future. There's a feeling that I can have a place in the story, that I can stop in the timeline, like the Keeper has done, and choose to stay in one universe and build out in it.

The question is, how will I feel about this universe when I get there? Will there be that sense of excitement and hope in creating a cool story in the unknown,
or,
will I gaze up at the stars on one of my outposts, and feel the looming dread of the the Hunter and other endgame characters, in that sense of a nightmarish alien timeloop, looking at the simplistic companion characters as pre-time warping simpletons, question my character's sanity in contrast to The Pilgrim's, and put down the game?