# FLOWMAKER’s Perspective and Glossary

The words on this site are based on a perspective of reality. 
This perspective arises from a model that is simple and follow’s as such: 

# Consciousness

We exist inside of a consciousness. 

This consciousness has an awake state and a sleeping state. 

An awake state of consciousness is known as awareness, and there are levels of awareness. 

A sleeping state of consciousness is known as ignorance or unawareness, and is autonomic. 

As an individual consciousness, we participate in consciousness in aware and unaware states, and our participation affects consciousness. 

# Reality

Reality is life as it is, real life. Our thinking can either be more or less associated to reality. 

This creates an individuated perspective of reality for us, created in terms we can understand. 

# Spirit

Spirit is the “voice”, “breath”, “light”, “knowing” of consciousness, it is not individuated and once it is observed, this is easily referred to as, “activated”. 

Once it is activated, unawareness will autonomously react to light as a threat and attempt to destroy it. 

Spirit appears to be an awake intelligence existing in consciousness, which is is heard in what is  known as soundless meaning. Mankind often calls this soundless meaning “revelation”, 

which in a modern world we might call, “a direct download of meaning”, 

the meaning of the information is understood fully without the use of language or symbols. 

# Philosophy and Religion

Humans interpret reality into meaningful words, and pass these words to other humans. 

Experiential information is information you have firsthand experience with. 

All other information you receive from others and reinterpret based on your known experience. 

Humans often interpret firsthand information which is real, then interpret that information within a limited scope. This creates what as known as subjective reality. 

# Truth

Truth can only be validated if the individuated consciousness can validate it as true, as real and not false. 

The truth inherent in life is that life has worth or value. 

If life has worth, that worth can be observed by an evaluation of value. 

If life has value, life becomes sacred. This means precious, it is worthy of being valued. 

# Sight

If life has no value, nothing is inherently sacred, and this is known as *‘blindness’.* 

Sight is the ability to appreciate value inherent in life, and evaluate that value. 

# Understanding

Understanding, or our level of clarity is the ability to comprehend meaningful information in a more or less complicated way. If our thinking is complicated, we have little clarity. 

As our thinking becomes more clear, it is easier for us to comprehend meaningful information. 

‘Darkness’ is associated with confusion because it involves complex thinking which clouds understanding. 
’Light’ is associated with understanding because clarity *‘illuminates’* the meaning inherent in information. 

# The All Reality

I have described this reality in many ways, one of them being as so, 
*”In that reality which is coming, 
there is only perfection, infinite and instant revelation of meaning, infinitely meaningful experiences that come at a rate of perfect flow from one to the next, all good things of reality come together such as family and connection, there is no suffering, there is nothing but fulfillment and miracles and possibilities of destiny transpiring, 
there is no darkness, no fear, no injury, 
that's all on the outside, 
on the inside there is infinite healing of all wounds, there is the pure and perfect person that is complete and loved, a life which is a celebration of the miracle of existence itself. 

The way this happens makes it a definitive outcome that all realities dissolve into the actual Reality. 
This is because when Reality comes, 
it is like a wave of truth which evaporates any untruth that had appeared before it.”* 

---

Answers to questions: 

“W*hat is light in your writings?”*

“Light in my writings is related to a newness, fresh thought.
Light is also truth and realness,
for example, if I expose the darkness of what is lies to the truth of what exists right now, that darkness is changed and destroyed upon contact,
An alchemical reaction changes the outcome.
Light is like the creative force, it is also like the restoration of the original image.
Light is also what is happening now.
There is a consideration, that if you are perceiving darkness in your soul, it is because you are the light perceiving the darkness.
You cannot see any darkness unless you are the light.
This means that you are the light of the world but you don't know or notice it,
You don't notice that you are the light of the world.
You perceive yourself as the darkness, but the one who is looking at the darkness is light.
The light also has intentions.
Why do you want to heal? Why do you want to be better? Why do you want to be different? Why do you want to change? Why do you want to be without sin? Why do you want to not be evil? Why do you want to be fixed? Why do you want to be whole?
Why do you want to not suffer?
Why do you not want to be in pain?
Why do you want to be loved?
It is because you are not the self which wishes to be loved,
You are that which is wishing for the self to be loved.
You are that which is always intending good things for you in every perceivable way and area of your life.
Is it not true? Are not all of your real intentions to have a better life?
Everything every intention everything you do is trying to figure out how to be loved, not abandoned, not rejected, not sick, not hurt,

Look and see if this is true,
In every moment of your life you want to be cared about you want to win,
That is you, the light, always there, that has been with you in your every striving.
You are the light of the world, but if in you is a speck of darkness, how great is that darkness?
The answer is that darkness is so great it is a darkness that casts across the entire world,
Because your light always casts across the entire world.
If you do not know that you are the light, and you believe that you are the darkness in you, that darkness projects across the earth because that darkness is a form of blindness,
that blindness is the blindness of not perceiving the light.

And if you do not see that you are the light you will not see that others are the light either

And when you really see it,
You see that there is nothing of the self that is not the dust of the earth.
When you are the light you see that Satan is a great metaphor for the self because the self is not even alive,
it is a mechanical automation, nothing but dust and it is no different than any other dust.

All of this world's automations are metaphors for the dead world which appears to be alive.
The self appears to be alive but it is only a part of the unfolding of all things.
Everything unfolding in this world is playing out exactly as it was going to play out, including the lives of all people. The objects in motion stay in motion until an equal or opposite force opposes them.
It is not unless an outside change element enters the old picture that the picture will change in any way.
The only thing that is actually alive is not in this world. The only thing that is actually alive is new and it is unknown and it is that which can be injected into the old picture if we choose to consciously participate with it,
That is why all of this has so much to do with letting things go”