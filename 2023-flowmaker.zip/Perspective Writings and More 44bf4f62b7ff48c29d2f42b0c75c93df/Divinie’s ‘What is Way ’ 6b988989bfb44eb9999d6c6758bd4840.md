# Divinie’s ‘What is Way?’

Christ said, *I am the Way, the Truth, and the Life.*
Could it be possible that Christ was describing how he understood himself as an existence?

After all, what is a man but his thoughts, feelings and actions?

What if Christ knew and identified himself with his Way -- of Life --, as Truth, that which is Authentic and not what the unauthentic, and as his Life, not as the microorganism known as the self, but as the totality of his reality,
as the relationships, associations and data of his world passed as data through his single consciousness?

Christ said, *I am the Vine.*

> *“I am the true vine, and my Father is the gardener. He cuts off every branch in me that bears no fruit, while every branch that does bear fruit he prunes so that it will be even more fruitful. You are already clean because of the word I have spoken to you. Remain in me, as I also remain in you. No branch can bear fruit by itself; it must remain in the vine. Neither can you bear fruit unless you remain in me.*
> 

> *“I am the vine; you are the branches. If you remain in me and I in you, you will bear much fruit; apart from me you can do nothing. If you do not remain in me, you are like a branch that is thrown away and withers; such branches are picked up, thrown into the fire and burned. If you remain in me and my words remain in you, ask whatever you wish, and it will be done for you. This is to my Father’s glory, that you bear much fruit, showing yourselves to be my disciples.*
> 

> *“As the Father has loved me, so have I loved you. Now remain in my love.  If you keep my commands, you will remain in my love, just as I have kept my Father’s commands and remain in his love. I have told you this so that my joy may be in you and that your joy may be complete.  My command is this: Love each other as I have loved you.  Greater love has no one than this: to lay down one’s life for one’s friends. You are my friends if you do what I command. I no longer call you servants, because a servant does not know his master’s business. Instead, I have called you friends, for everything that I learned from my Father I have made known to you. You did not choose me, but I chose you and appointed you so that you might go and bear fruit—fruit that will last—and so that whatever you ask in my name the Father will give you. 

This is my command: Love each other.*
> 

If Christ is the Life, and the Vine,
the Life is the Vine,
The Vine is a network.
Christ knows himself as the network, not the node.

As master of his reality, he is the gardener of the Vine.
He is the master gardener of his *di-vine* reality.

His role in consciousness, as that which chooses and intends, is to tend to the garden,
to trim and cut off bad branches,
what we now call neural connections, what we see in the physical world as represented on a micro-scale as neural pathways and as a macroscale as other human relationships and explorations of thought.

One could say that our father has given us a Mind, and our job is to tend to it and nurture it to be good.

Christ's role as the vinedresser is to manage the garden that his father has placed in his care,
that is,
to manage the network that his father has placed in his care.

---