# Writings on the Awareness

*Captured from a discussion* 

This is a unique part of experiencing eternity,
when you experience all reality,
there is infinite sensation, almost like a dream, and you've always been in all of it you've just been experiencing a fragment of it, it's essentially pure experience.
during an experience of this,
'you' disappear, your experience of self is not there, there is only existence, the experiencer as a noun is no longer present, because there is no body, there never was a body, that's just an identification with part of the experience. You can experience reality as one without the identification of your body, and this would feel like, 'sensation without 'my' existence'.
This experience of everything is accurately described as an ocean, it feels fluid and water-like and there is a rushing quality to it, and the amount of sensations are infinite and never-ending,
but just as you float down a stream and get snagged by a branch, you will likely be pulled out of the experience and back to 'reality' once you start to identify again.

where memory is is stored is a great question, in these experiences, my vessel contained a memory of the experience,
of course the memory does not include all of the data of that experience.

---

There is a concept that because vibrations   ripple through the universe into eternity, those ripples are never destroyed because there is nothing to destroy them,
and that because of this, no data is ever destroyed in consciousness, which would mean that there is an 'eternal memory'.
However, that memory would be accurate to reality, as it actually was,
unlike our memories which are not accurate to reality, which include stories and subjective feelings about what an experience meant or why it happened.
This is also why scripture talked about a 'perfect image', the perfect data is unstained by our unperfect shadows and perspectives and filters we placed upon that image, we distort the image and memory through our own eyes.

in the experience you're talking about,
a person's awareness would have left the awareness of the body and be perceiving all of reality,
you are still limited to a scope of information in this experience, you still 'navigate' or are 'navigated to', in a parable,
it would be like billions of images coming at you without end or time to process,
just pure infinite meaning.

During this experience, it would not be possible for you to know if you still possessed a physical body, your awareness is not tracking it. You would have to have others identify if they still saw your physical body during that period of time,
and you would have to determine that you were even there during that period of time.

I would expect that because during that experience you are not in the body, that no harm would come to the awareness you were experiencing if the body were to perish,
but again that experience of awareness doesn't have a 'you' with it in the first place, so in a sense you have returned to god,
or in another sense, you have fallen back asleep into another dream, swept away into a current of experience.

That experience I can say is as though you are neither here nor there nor anywhere, there is happening, nothing is happening to you, there is an observing, but there is no you observing anything, there is an observation happening, but there is no subject, there is no observer, the observer is existence itself.

If you have this kind of experience, you become aware that existence is essentially infinite experience, that what existence means is experience.

Enoch and Elijah, but primarily Enoch, are expected to have left the body into that experience and never came back.
Other masters are expected to have left into forests in the same way and never returned.
[This referring to the Enoch of Enoch 1 of dead sea scrolls,
not Enoch 2 3 4 etc. which are later occult works with no association]

From my experience,
what I would say if you wanted to find out if you can exist outside of the infinite experience,
If you can exist in non-existence,
is that 'you' [however that makes sense]
your illusion would somehow have to be more powerful than god, and I say that in terms of 'strength',
because that oceans current is infinitely and unbelievably powerful.
As soon as you leave the experience of the self your 'awareness' would be going back into that current,
you would have to be stronger than the universe to swim outside of the current of the ocean, outside of the sensations of all of existence, if there is an outside.
[11:06 PM]The Living Divinie: once you've had this experience you recognize that 'self' is less of a 'thing' and more like an shrinkage,
it's a very tiny thing.
it's super tiny and its sensations are limited,
which gives you some ability to look and reflect and question and reason about what's happening to you.

when you exit the shrinkage, you no longer have the time to look back and reflect or not feel 'overwhelmed'.
in full experience you're going to be infinitely 'overwhelmed',
but you also experience pure meaning,
so instead of a shrinkage experience where nothing is particularly meaningful,
the expanded experience is direct meaning,
everything infinitely matters and you have the data to know it

so to say, 'can i experience non-existence'
is like saying,
'can i navigate my shrink state to the edge of the ocean and jump out'
it would be difficult
but what you can do is shrink further until there is no meaning left,
and then you would experience a meaningless experience

because you'd be focused on a tiny black dot and expand that black dot to your entire awareness,
and the black dot wouldn't mean anything,
it's just a black dot

---

my experience of the awareness is that it is singular, it has a quality to it, a signature to it that is recognizable, and it does match the definition of the 'oneness' that has been described as many, as people say it is 'impersonal', not that it is not caring, but that it is 'not individuated',
and from this you could fathom that the awareness is God, that all of us are of God, His body parts,
whether or not there is a God behind the awareness is a question, there is the experience of direct data coming from outside of the closed system,
so if your definition of God is that which is outside of the closed system, then God does exist,
you can prove the awareness is a singular once you have experienced that it is the same awareness in the animals and other people,
there is a moment of recognition that that which is in me is perceiving that which is in you and that it is the same, the two awarenesses link together and there is an exchange of this data, an acknowledgement and there is enough data in the transaction to know it is so, because none of the data is hidden, it's all visible in that moment, the checksum verifies against itself.

It may be a poetic or human abstraction or conception of the mind to conclude this of the experience, but it is experienced that it is God looking through the awareness, through you, that the one looking out of the awareness is God, the very same God looking through all points of awareness, a singular consciousness,
which says that we are all 'of God', that we are God as it is 'zoomed in' and hyper-focused on certain points, and that the God behind all those points, the
singular awareness, is aware of all points at once.
This is, if you were to zoom out, you would see all points, if I were to zoom out, I would see all points.
To have even two points see each other is exceptionally meaningful, to have more points in communion would be astronomically meaningful.

The statement that laws may violate the existence of the awareness without the body is a good statement to make,
because the law in question would be that there could be a law that if there is a physical,
there is a spiritual, if there is a spiritual, there is a physical, that they happen at once and are linked together.
My data suggests that the awareness can exist without the physical, and that this normal law can be broken by the awareness.

---

It does seem to be the case that the reason why the awareness is at a center point, is not because it was born at that point, God was not born behind your eyes,
but the awareness like other things in nature seems to be strongly attracted to, gravitated towards these points.
You could say that the reason why the awareness stays behind your eyes is not only to protect you, but also because it strongly gravitates to that point.
In my experiences, my awareness quickly gravitated back to its home,
and it is experienced by many that they are 'spiritually attacked' by others looking for a home if their awareness has left their body.
In this concept, the awareness gravitates toward any open point that there is to look out from.

---

This is my favorite topic not because of philosophy but because my consciousness expands again when focusing on the topic,
and because I am extremely fortunate to exist in a world where other minds describe the same experience,
where they have come up with terms such as 'oneness' and 'consciousness' and 'God' and 'impersonal' and 'awareness' to describe the same experience I have had.

I am also grateful for this because when my consciousness expands again, I am no longer as worried about the many beliefs and conclusions about what is that my mind has been filled with by my own cultures and religions. The fear of being wrong is evaporated by the hard data.