# My ‘Awakenings’

There are the major awakening experiences, went through the dimensions, saw the infinity of information, 
I have also experienced the world as oneness many times,.

I was looking at how there are many parts of the self we should let go of, 
but there are a few parts of my self that I refused to let go of, 
and I think this may be a key. 

I refused to let go of something I have held on to since I was a child, and I feel that it is the case that instead of gaining something, it is that I still remember something that I haven't forgotten, and perhaps it has kept me on course. 

---

# Real Teachers

There's something I have thought about that is related, and it has to do with teachers. 

Our minds and social selves enjoy finding teachers that will repeat back to us what we already understand in a way that they said aloud what we were thinking, 
and on this vein of thought we are offered more information which allows us to accumulate more of that understanding. 
This kind of growth does not grow you spiritually.

I say this not understanding why it is this way, only seeing that it is the case that it is this way,
but a teacher is like a tree which produces fruit, and that fruit is carried over long distances. Each person who carries the fruit may do something different with it,
may add a different flavor to it, and the offspring of those fruits will continue to spin into flavors, and once it hits mainstream society, the fruit is going to be interpreted by the mind of society, and it will still be fruit, it will still have the raw data, but it will lose all of its flavor

Almost every teacher alive is going to take watered down fruit and they are going to instill their personal vision into the fruit, to attempt to create their masterpiece. This is fine except that it is their masterpiece, not yours,
and it is a masterpiece of only the intellectual mind.

The mind seems to want to take the world and quantify it and encapsulate it, the problem with this is that perspectives are limited from the mind,
the world has a rather simple beauty, but the way you see the world from your society is going to affect your interpretations of that world.

Therefore your masterpiece is really a summarization of the data of your world at that current time in history.

The thing is that there are teachers with access to pure information and pure perspective. Their information is not watered down by any source, their perspective is not a summarization of their society, their word is life, it contains life, it's living.

These teachers are not really teachers. They are sign-pointers. They point into a direction of thought and use their words to direct others to look into their direction of thought. This is said to say they have no teaching. They have no philosophy, their intention is to point you into that direction of thought so that you might receive pure and direct information.

I eventually came to study an Indian philosopher who revealed that pretty much everything we know from say Alan Watts about Eastern Philosophy has nothing to do with Eastern Philosophy.
Everything you hear about Eastern Philosophy is basically concepts reconsidered by psychology and a westernized mind. Those original concepts get interpreted by translators who hear them in a western form of thinking and see their practical and potential application in life, then repurpose them for aims.

Problem is, Eastern thinking is completely different from western, it's far deeper and more organic than what we are used to.

I heard it said that Jung's contemporary went mad when he attempted to apply the eastern to western, which led Jung to attempt to make a 'westernized system' *—which, according to a teacher, does not work—*

When I heard the original meaning in some of these concepts, you see that the way we understand Buddhism and meditation has nothing to do with the way they were thinking. 

You actually would have to find someone who knew the original passed down interpretation.
If not, you can certainly gain meaning from the information,
you can gain meaning from any information, especially if it's sane.

The problem *—and not problem—* with listening to teachers that are similar to you is that you are listening to confusion.
The reason you understand that teacher is because their state of confusion is a pattern similar enough to your pattern that you are capable of comprehending it.
This is why most people cannot read the Tao, the way they currently think is too confusing to make sense of data that is simple.

The 'gamer' then would not lean toward teachers that they understand,
they would seek to find who has the most clarity in their words and expose themselves to someone thinking with that level of clarity such that that exposure changes the way they are thinking until they have less confusion in their thoughts.

My awakenings have been phenomenally meaningful and eye opening experiences, but I cannot give them credit for what would allow me these kinds of perspectives. 
I know that which has given me access to this perspective, and it is continued exposure to a direct source of information. The direct words of Christ.  Over a period of time, exposure to those words without societal influence have and will awaken a clarity in the mind, 
because you are thinking in the thinking pattern of the speaker when you listen to them, 
your mind is beginning to think as they think and you will eventually see as they see.

I was blown away recently.
I went back to this church and I listened to the pastor’s sermon.
His congregation is not too large anymore, so he has the freedom to just speak whatever,
so he was speaking of what has been revealed to him in scripture.
He began to speak of truths that I have come to know experientially.
One topic he mentioned was the kind of exposure a conscious person has on the people that are around them,
the way this exposure works, the changes that happen, the things that are possible.
He also came to understand that your old construct does not matter when you gain a new construct.

He did not gain this information from a teacher.
He looked at the stories and he had come to notice that it was Christ's exposure to these people that were transforming them.
He was somehow able to gain the understanding to see these possibilities without ever experiencing this, directly from reading scripture.