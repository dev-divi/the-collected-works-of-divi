# Divi’s Game Development Journey

Development Concepts Mind Map

[https://www.figma.com/file/3OXBBEuxzQFwFx5pDqbS3E/Untitled?type=design&node-id=0-1&mode=design&t=RE4NSisZRH874mtE-0](https://www.figma.com/file/3OXBBEuxzQFwFx5pDqbS3E/Untitled?type=design&node-id=0-1&mode=design&t=RE4NSisZRH874mtE-0)

---

![divigamedevjourney.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/divigamedevjourney.png)

![divithegamedev-v2.2.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/divithegamedev-v2.2.png)

Green: Resources 

Yellow: Personal or Inapplicable 

Red: Not useful

# Game Plan

[Untitled Database](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/Untitled%20Database%200888425a4d5745839b8684be6c1cc724.csv)

| little goals:  |  |
| --- | --- |
|  | experiment with gunvolt in online pixel art editor  |
|  |  |

[RigidBody 2D ](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/RigidBody%202D%202f9d19209f3c476bac8bc7b922f29e0b.md)

Make 10 2D game prototypes and release them on steam 

release 3 of them on mobile

Make 3 3D game prototypes and release them on steam 

make micro-projects so they can be completed shipped deployed. 
continuous games in a small space with a high score. 

- metroidvania game jam
    
    
    # 
    
    ## Game Components:
    
    -1 character who floats and spins and sword attacks 
    
    *“1 boss 1 biome
    2-3 enemies
    2 upgrades”*
    
    ## PART II: Game Design Components:
    
    Break down all elements of design into 
    -Sprites 
    
    -Tilemaps —
    
    -World 
    
    -Scripts 
    
    **Alt Plan:** Reverse-engineer a game like Dead Cells 
    
    ## Plan Initial Start:
    
    Take introduction to Tilemaps today 
    
    Assemble Game Resources 
    
    ## Game Resources:
    
    may be redundant — move to unity game design after this 
    
    [https://assetstore.unity.com/packages/2d/environments/platformer-set-150023](https://assetstore.unity.com/packages/2d/environments/platformer-set-150023)
    
    Thoughts: 
    
    - “If you’re struggling to gauge how much you should aim for, I’d suggest the following targets:
        
        
        Relatively new to game jams or low staff/time:.
        1 boss 1 biome
        2-3 enemies
        2 upgrades
        
        If you’re stuck with how to start on level design for a Metroidvania, start by going small. A good place to start is with a 3x3 room layout.
        
        you’re going to need to make at least 1 tileset, and a set of player animations, and animations for enemies and power ups
        
        if you’re building melee animations for the main character, animating them on a grid that’s three times larger than the base character helps give plenty of room for bigger hitboxes and expressive animations. If your game’s tiles are on 16x16, you’d animate your character on 48x48.
        
        You shouldn’t build difficulty from tedium. There are many ways to add challenge into a Metroidvania, but damage sponges are boring. There is an element of taste here, but if you’re spending multiple moments at a time doing nothing but pressing a button to do damage, without having to dodge or otherwise make a reaction or decision, the enemy is probably too tanky. The same goes for super long platforming segments with death pits and few checkpoints. There can be ways to make it thematically appropriate, but this is one of those things you want to learn to do right, before you break it. Highly punishing platforming segments (or the same in other genres) also get tedious after a while. Variety helps make a pleasant experience. A good question to consider is “can I get this level design idea across in fewer ‘screen’s of map than what I’m currently using?” The more screens you have, the more you’ll need to find ways to mix things up, the fewer screens, the more your existing variety spices things up.
        
    

Game Inspirations: 

[GitHub - dev-divi/The-Collection-Lists](https://github.com/dev-divi/The-Collection-Lists/tree/main)

[https://www.youtube.com/watch?v=-gzw_DHfoKU&t=94s&ab_channel=WillyDev](https://www.youtube.com/watch?v=-gzw_DHfoKU&t=94s&ab_channel=WillyDev)

# 2D Game Design

[https://assetstore.unity.com/packages/2d/environments/platformer-set-150023](https://assetstore.unity.com/packages/2d/environments/platformer-set-150023)

[Introduction to Tilemaps - Unity Learn](https://learn.unity.com/tutorial/introduction-to-tilemaps#)

[Using 9-Slicing for Scalable Sprites - Unity Learn](https://learn.unity.com/tutorial/using-9-slicing-for-scalable-sprites-2#5f7cf6b3edbc2a00251b988c)

# **2D GAME ART PDF**

[2D game art, animation, and lighting for artists.pdf](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/2D_game_art_animation_and_lighting_for_artists.pdf)

### Videogame Sprites

- 3DS
    
    
    [https://www.spriters-resource.com/3ds/supermariomakerfornintendo3ds/](https://www.spriters-resource.com/3ds/supermariomakerfornintendo3ds/)
    
    [https://www.spriters-resource.com/3ds/azurestrikergunvolt/](https://www.spriters-resource.com/3ds/azurestrikergunvolt/) 
    
    [https://www.spriters-resource.com/3ds/projectxzone/](https://www.spriters-resource.com/3ds/projectxzone/)
    
    [https://www.spriters-resource.com/3ds/papermariostickerstar/](https://www.spriters-resource.com/3ds/papermariostickerstar/)
    
- sprite backup
    
    on github
    

2D Official Docs Specific 

[2D Tilemap Extras | 2D Tilemap Extras | 1.6.0-preview.1](https://docs.unity3d.com/Packages/com.unity.2d.tilemap.extras@1.6/manual/index.html)

## 

Sort Sprites documentation [https://docs.unity3d.com/Manual/sprites-sort.html](https://docs.unity3d.com/Manual/sprites-sort.html) ****[layer sprites]**** 

2d lighting 

![quickstart-lighting-2d.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/quickstart-lighting-2d.png)

### More 2D

### A 2D Game Tutorial

[https://livebook.manning.com/book/unity-in-action-second-edition/chapter-6/](https://livebook.manning.com/book/unity-in-action-second-edition/chapter-6/) ****

### Another 2D Game Tutorial

[https://gamedevacademy.org/how-to-build-a-complete-2d-platformer-in-unity/](https://gamedevacademy.org/how-to-build-a-complete-2d-platformer-in-unity/)

[this was recently updated in march 2023 ]

[https://vionixstudio.com/2022/11/04/2d-platformer-in-unity/](https://vionixstudio.com/2022/11/04/2d-platformer-in-unity/)

- more
    
    **Information** [https://gamedevacademy.org/best-courses-unity-associate-game-developer-certification/](https://gamedevacademy.org/best-courses-unity-associate-game-developer-certification/)
    
    ### Unity Game Degree Information
    
- **2d game notes to self**
    
    the unused item sprites from mighty gunvolt i want to use. 
    
    I want to learn how to use the tileset from mighty gunvolt 
    

# 3D Game Creation Plans and Files

# MonkGameV3:

[A Floating Monk Flying Description](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/A%20Floating%20Monk%20Flying%20Description%20b95d6e3f57814bbda620eb5179cb3f80.md)

# Research

**these three courses are everything I wanted.** 

- penny de byl
    
    [https://www.udemy.com/course/games_mathematics/](https://www.udemy.com/course/games_mathematics/) 
    
    [https://www.udemy.com/course/unity-complete/](https://www.udemy.com/course/unity-complete/)
    
    [https://www.udemy.com/course/create-a-third-person-player-character-controller/](https://www.udemy.com/course/create-a-third-person-player-character-controller/)
    
    [Holistic Game Development with Unity 3e: An All-in-One Guide to Implementing Game Mechanics, Art, Design and Programming](https://www.amazon.com/Holistic-Game-Development-Unity-All/dp/1138480622)
    

- rotn blog
    
    seems to be down. try later? 
    
    [https://www.reddit.com/r/gamedev/comments/880yr0/i_took_dr_penny_de_byls_unity_shader_course_so/](https://www.reddit.com/r/gamedev/comments/880yr0/i_took_dr_penny_de_byls_unity_shader_course_so/)
    

- next level dev
    
    

# Start Resources

### 2D Official Unity Manual

[https://docs.unity3d.com/Manual/Quickstart2DCreate.html](https://docs.unity3d.com/Manual/Quickstart2DCreate.html)

## Resources and Learning

### Simulate Gravity in Unity

[How to Simulate Gravity in Unity](https://www.youtube.com/watch?v=Ouu3D_VHx9o&list=PLPV2KyIb3jR5qEyOlJImGFoHcxg9XUQci&t=484s&ab_channel=Brackeys)

### Unity Advanced Playlist

[https://www.youtube.com/playlist?list=PLPV2KyIb3jR5qEyOlJImGFoHcxg9XUQci](https://www.youtube.com/playlist?list=PLPV2KyIb3jR5qEyOlJImGFoHcxg9XUQci)

### Unity RPG Game Tutorial

[How To Create An RPG Game In Unity - Comprehensive Guide - GameDev Academy](https://gamedevacademy.org/how-to-create-an-rpg-game-in-unity-comprehensive-guide/)

[Unity Game Development Mini-Degree](https://academy.zenva.com/product/unity-game-development-mini-degree/?zva_src=gamedevacademy-bestgamedevassociatecert)

# notes db

[notes db](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/notes%20db%20d452f1994eac48348930d2d3dcabfde6.csv)

# Physics

- Rigidbody Properties
    
    ### **Properties**
    
    | https://docs.unity3d.com/ScriptReference/Rigidbody-angularDrag.html | The angular drag of the object. |
    | --- | --- |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-angularVelocity.html | The angular velocity vector of the rigidbody measured in radians per second. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-automaticCenterOfMass.html | Whether or not to calculate the center of mass automatically. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-automaticInertiaTensor.html | Whether or not to calculate the inertia tensor automatically. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-centerOfMass.html | The center of mass relative to the transform's origin. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-collisionDetectionMode.html | The Rigidbody's collision detection mode. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-constraints.html | Controls which degrees of freedom are allowed for the simulation of this Rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-detectCollisions.html | Should collision detection be enabled? (By default always enabled). |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-drag.html | The drag of the object. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-excludeLayers.html | The additional layers that all Colliders attached to this Rigidbody should exclude when deciding if the Collider can come into contact with another Collider. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-freezeRotation.html | Controls whether physics will change the rotation of the object. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-includeLayers.html | The additional layers that all Colliders attached to this Rigidbody should include when deciding if the Collider can come into contact with another Collider. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-inertiaTensor.html | The inertia tensor of this body, defined as a diagonal matrix in a reference frame positioned at this body's center of mass and rotated by Rigidbody.inertiaTensorRotation. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-inertiaTensorRotation.html | The rotation of the inertia tensor. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-interpolation.html | Interpolation provides a way to manage the appearance of jitter in the movement of your Rigidbody GameObjects at run time. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-isKinematic.html | Controls whether physics affects the rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-mass.html | The mass of the rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-maxAngularVelocity.html | The maximum angular velocity of the rigidbody measured in radians per second. (Default 7) range { 0, infinity }. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-maxDepenetrationVelocity.html | Maximum velocity of a rigidbody when moving out of penetrating state. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-maxLinearVelocity.html | The maximum linear velocity of the rigidbody measured in meters per second. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-position.html | The position of the rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-rotation.html | The rotation of the Rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-sleepThreshold.html | The mass-normalized energy threshold, below which objects start going to sleep. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-solverIterations.html | The solverIterations determines how accurately Rigidbody joints and collision contacts are resolved. Overrides Physics.defaultSolverIterations. Must be positive. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-solverVelocityIterations.html | The solverVelocityIterations affects how how accurately Rigidbody joints and collision contacts are resolved. Overrides Physics.defaultSolverVelocityIterations. Must be positive. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-useGravity.html | Controls whether gravity affects this rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-velocity.html | The velocity vector of the rigidbody. It represents the rate of change of Rigidbody position. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody-worldCenterOfMass.html | The center of mass of the rigidbody in world space (Read Only). |
    
    ### **Public Methods**
    
    | https://docs.unity3d.com/ScriptReference/Rigidbody.AddExplosionForce.html | Applies a force to a rigidbody that simulates explosion effects. |
    | --- | --- |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.AddForce.html | Adds a force to the Rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.AddForceAtPosition.html | Applies force at position. As a result this will apply a torque and force on the object. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.AddRelativeForce.html | Adds a force to the rigidbody relative to its coordinate system. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.AddRelativeTorque.html | Adds a torque to the rigidbody relative to its coordinate system. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.AddTorque.html | Adds a torque to the rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.ClosestPointOnBounds.html | The closest point to the bounding box of the attached colliders. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.GetAccumulatedForce.html | Returns the force that the Rigidbody has accumulated before the simulation step. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.GetAccumulatedTorque.html | Returns the torque that the Rigidbody has accumulated before the simulation step. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.GetPointVelocity.html | The velocity of the rigidbody at the point worldPoint in global space. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.GetRelativePointVelocity.html | The velocity relative to the rigidbody at the point relativePoint. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.IsSleeping.html | Is the rigidbody sleeping? |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.Move.html | Moves the Rigidbody to position and rotates the Rigidbody to rotation. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.MovePosition.html | Moves the kinematic Rigidbody towards position. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.MoveRotation.html | Rotates the rigidbody to rotation. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.ResetCenterOfMass.html | Reset the center of mass of the rigidbody. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.ResetInertiaTensor.html | Reset the inertia tensor value and rotation. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.SetDensity.html | Sets the mass based on the attached colliders assuming a constant density. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.Sleep.html | Forces a rigidbody to sleep at least one frame. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.SweepTest.html | Tests if a rigidbody would collide with anything, if it was moved through the Scene. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.SweepTestAll.html | Like Rigidbody.SweepTest, but returns all hits. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.WakeUp.html | Forces a rigidbody to wake up. |
    
    ### **Messages**
    
    | https://docs.unity3d.com/ScriptReference/Rigidbody.OnCollisionEnter.html | OnCollisionEnter is called when this collider/rigidbody has begun touching another rigidbody/collider. |
    | --- | --- |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.OnCollisionExit.html | OnCollisionExit is called when this collider/rigidbody has stopped touching another rigidbody/collider. |
    | https://docs.unity3d.com/ScriptReference/Rigidbody.OnCollisionStay.html | OnCollisionStay is called once per frame for every Collider or Rigidbody that touches another Collider or Rigidbody. |
    
    ### **Inherited Members**
    
    ### **Properties**
    
    | https://docs.unity3d.com/ScriptReference/Component-gameObject.html | The game object this component is attached to. A component is always attached to a game object. |
    | --- | --- |
    | https://docs.unity3d.com/ScriptReference/Component-tag.html | The tag of this game object. |
    | https://docs.unity3d.com/ScriptReference/Component-transform.html | The Transform attached to this GameObject. |
    | https://docs.unity3d.com/ScriptReference/Object-hideFlags.html | Should the object be hidden, saved with the Scene or modifiable by the user? |
    | https://docs.unity3d.com/ScriptReference/Object-name.html | The name of the object. |
    
    ### **Public Methods**
    
    | https://docs.unity3d.com/ScriptReference/Component.BroadcastMessage.html | Calls the method named methodName on every MonoBehaviour in this game object or any of its children. |
    | --- | --- |
    | https://docs.unity3d.com/ScriptReference/Component.CompareTag.html | Checks the GameObject's tag against the defined tag. |
    | https://docs.unity3d.com/ScriptReference/Component.GetComponent.html | Gets a reference to a component of type T on the same GameObject as the component specified. |
    | https://docs.unity3d.com/ScriptReference/Component.GetComponentInChildren.html | Gets a reference to a component of type T on the same GameObject as the component specified, or any child of the GameObject. |
    | https://docs.unity3d.com/ScriptReference/Component.GetComponentInParent.html | Gets a reference to a component of type T on the same GameObject as the component specified, or any parent of the GameObject. |
    | https://docs.unity3d.com/ScriptReference/Component.GetComponents.html | Gets references to all components of type T on the same GameObject as the component specified. |
    | https://docs.unity3d.com/ScriptReference/Component.GetComponentsInChildren.html | Gets references to all components of type T on the same GameObject as the component specified, and any child of the GameObject. |
    | https://docs.unity3d.com/ScriptReference/Component.GetComponentsInParent.html | Gets references to all components of type T on the same GameObject as the component specified, and any parent of the GameObject. |
    | https://docs.unity3d.com/ScriptReference/Component.SendMessage.html | Calls the method named methodName on every MonoBehaviour in this game object. |
    | https://docs.unity3d.com/ScriptReference/Component.SendMessageUpwards.html | Calls the method named methodName on every MonoBehaviour in this game object and on every ancestor of the behaviour. |
    | https://docs.unity3d.com/ScriptReference/Component.TryGetComponent.html | Gets the component of the specified type, if it exists. |
    | https://docs.unity3d.com/ScriptReference/Object.GetInstanceID.html | Gets the instance ID of the object. |
    | https://docs.unity3d.com/ScriptReference/Object.ToString.html | Returns the name of the object. |
    
    ### **Static Methods**
    
    | https://docs.unity3d.com/ScriptReference/Object.Destroy.html | Removes a GameObject, component or asset. |
    | --- | --- |
    | https://docs.unity3d.com/ScriptReference/Object.DestroyImmediate.html | Destroys the object obj immediately. You are strongly recommended to use Destroy instead. |
    | https://docs.unity3d.com/ScriptReference/Object.DontDestroyOnLoad.html | Do not destroy the target Object when loading a new Scene. |
    | https://docs.unity3d.com/ScriptReference/Object.FindAnyObjectByType.html | Retrieves any active loaded object of Type type. |
    | https://docs.unity3d.com/ScriptReference/Object.FindFirstObjectByType.html | Retrieves the first active loaded object of Type type. |
    | https://docs.unity3d.com/ScriptReference/Object.FindObjectOfType.html | Returns the first active loaded object of Type type. |
    | https://docs.unity3d.com/ScriptReference/Object.FindObjectsByType.html | Retrieves a list of all loaded objects of Type type. |
    | https://docs.unity3d.com/ScriptReference/Object.FindObjectsOfType.html | Gets a list of all loaded objects of Type type. |
    | https://docs.unity3d.com/ScriptReference/Object.Instantiate.html | Clones the object original and returns the clone. |
    
    ### **Operators**
    
    | https://docs.unity3d.com/ScriptReference/Object-operator_Object.html | Does the object exist? |
    | --- | --- |
    | https://docs.unity3d.com/ScriptReference/Object-operator_ne.html | Compares if two objects refer to a different object. |
    | https://docs.unity3d.com/ScriptReference/Object-operator_eq.html | Compares two object references to see if they refer to the same object. |

[Penny’s book should cover physics concepts so hopefully I will be good with that] 

[physicsclassroom.com](http://physicsclassroom.com) 

## Physics

- Part 1: Kinematics
    
    **Vectors** are quantities that are fully described by both a magnitude and a direction.
    
    **Displacement** is a [vector quantity](http://www.physicsclassroom.com/Class/1DKin/U1L1b.cfm) that refers to "how far out of place an object is"; it is the object's overall change in position.
    
    • **Acceleration** is a [vector quantity](http://www.physicsclassroom.com/Class/1DKin/U1L1b.cfm) that is defined as the rate at which an object changes its [velocity](http://www.physicsclassroom.com/Class/1DKin/U1L1d.cfm). An object is accelerating if it is changing its velocity.
    
    A free-falling object has an acceleration of 9.8 m/s/s, downward (on Earth). This numerical value for the acceleration of a free-falling object is such an important value that it is given a special name. It is known as the **acceleration of gravity** - the acceleration for any object moving under the sole influence of gravity. A matter of fact, this quantity known as the acceleration of gravity is such an important quantity that physicists have a special symbol to denote it - the symbol **g**.
    
    ![U1L6a1.gif](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/U1L6a1.gif)
    
- Part 2: Newton’s Laws, Force
    
    The book in motion on the table top does not come to a rest position because of the *absence* of a force; rather it is the *presence* of a force - that force being the force of friction - that brings the book to a rest position. In the absence of a force of friction, the book would continue in motion with the same speed and direction - forever!
    
    [Inertia](http://www.physicsclassroom.com/Class/newtlaws/u2l1b.cfm#inertia) is the tendency of an object to resist changes in its state of motion. But what is meant by the phrase *state of motion*? The state of motion of an object is defined by its [velocity](http://www.physicsclassroom.com/Class/1DKin/U1L1d.cfm) - the speed with a direction. Thus, inertia could be redefined as follows:
    
    **Inertia: tendency of an object to resist changes in its velocity.**
    
    **Mass is that quantity that is solely dependent upon the inertia of an object. The more inertia that an object has, the more mass that it has.**
    
    **Equilibrium:** 
    
    There are two forces acting upon the book. One force - the Earth's gravitational pull - exerts a downward force. The other force - the push of the table on the book (sometimes referred to as a *normal force*) - pushes upward on the book.
    
    Since these two forces are of equal magnitude and in opposite directions, they balance each other. The book is said to be at **equilibrium**. There is no unbalanced force acting upon the book and thus the book maintains its [state of motion](http://www.physicsclassroom.com/Class/newtlaws/u2l1c.cfm#state). When all the forces acting upon an object balance each other, the object will be at equilibrium; it will not accelerate.
    
    **Unbalanced Force:** 
    
    Yet there is no force present to balance the force of friction. As the book moves to the right, friction acts to the left to slow the book down. There is an unbalanced force; and as such, the book changes its state of motion. The book is not at equilibrium and subsequently accelerates. [Unbalanced forces cause accelerations](http://www.physicsclassroom.com/Class/newtlaws/u2l1b.cfm). In this case, the unbalanced force is directed opposite the book's motion and will cause it to slow down.
    
    **Force:** 
    
    A **force** is a push or pull upon an object resulting from the object's *interaction* with another object. Whenever there is an *interaction* between two objects, there is a force upon each of the objects. When the *interaction* ceases, the two objects no longer experience the force. Forces only exist as a result of an interaction.
    
    **Contact Forces**
    Frictional Force
    Tension Force
    Normal Force
    Air Resistance Force
    
    Applied Force
    
    Spring Force
    
    **Action-at-a-Distance Forces**
    Gravitational Force
    Electrical Force
    Magnetic Force
    
    Newton: 
    
    Force is a quantity that is measured using the standard metric unit known as the **Newton**. A Newton is abbreviated by an "N." To say "10.0 N" means 10.0 Newton of force. One Newton is the amount of force required to give a 1-kg mass an acceleration of 1 m/s/s. Thus, the following unit equivalency can be stated:
    
    **1 Newton = 1 kg • m/s2**
    
    **A force is a vector quantity.** a vector quantity is a quantity that has both magnitude and direction. To fully describe the force acting upon an object, you must describe both the magnitude (size or numerical value) and the directio
    
    because forces are vectors, the effect of an individual force upon an object is often canceled by the effect of another force. For example, the effect of a 20-Newton upward force acting upon a book is *canceled* by the effect of a 20-Newton downward force acting upon the book. In such instances, it is said that the two individual forces *balance each other*; there would be no [unbalanced force](http://www.physicsclassroom.com/Class/newtlaws/u2l1d.cfm#balanced) acting upon the book.
    
- Part 3: Force Types
    
    
    | Type of Force(and Symbol) | Description of Force |
    | --- | --- |
    | Applied Force
     Fapp | An applied force is a force that is applied to an object by a person or another object. If a person is pushing a desk across the room, then there is an applied force acting upon the object. The applied force is the force exerted on the desk by the person.http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#Top |
    | Gravity Force
     (also known as Weight)
     Fgrav | The force of gravity is the force with which the earth, moon, or other massively large object attracts another object towards itself. By definition, this is the weight of the object. All objects upon earth experience a force of gravity that is directed "downward" towards the center of the earth. The force of gravity on earth is always equal to the weight of the object as found by the equation:Fgrav = m * gwhere g = 9.8 N/kg (on Earth)
    and m = mass (in kg)
    http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#mass
    http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#Top |
    | Normal Force
     Fnorm | The normal force is the support force exerted upon an object that is in contact with another stable object. For example, if a book is resting upon a surface, then the surface is exerting an upward force upon the book in order to support the weight of the book. On occasions, a normal force is exerted horizontally between two objects that are in contact with each other. For instance, if a person leans against a wall, the wall pushes horizontally on the person.http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#Top |
    | Friction Force
     Ffrict | The friction force is the force exerted by a surface as an object moves across it or makes an effort to move across it. There are at least two types of friction force - sliding and static friction. Though it is not always the case, the friction force often opposes the motion of an object. For example, if a book slides across the surface of a desk, then the desk exerts a friction force in the opposite direction of its motion. Friction results from the two surfaces being pressed together closely, causing intermolecular attractive forces between molecules of different surfaces. As such, friction depends upon the nature of the two surfaces and upon the degree to which they are pressed together. The maximum amount of friction force that a surface can exert upon an object can be calculated using the formula below:Ffrict = µ • Fnorm
    The friction force is discussed in more detail http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#friction.http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#Top |
    | Air Resistance Force
     Fair | The air resistance is a special type of frictional force that acts upon objects as they travel through the air. The force of air resistance is often observed to oppose the motion of an object. This force will frequently be neglected due to its negligible magnitude (and due to the fact that it is mathematically difficult to predict its value). It is most noticeable for objects that travel at high speeds (e.g., a skydiver or a downhill skier) or for objects with large surface areas. Air resistance http://www.physicsclassroom.com/Class/newtlaws/u2l3e.cfm.http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#Top |
    | Tension Force
     Ftens | The tension force is the force that is transmitted through a string, rope, cable or wire when it is pulled tight by forces acting from opposite ends. The tension force is directed along the length of the wire and pulls equally on the objects on the opposite ends of the wire.http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#Top |
    | Spring Force
     Fspring | The spring force is the force exerted by a compressed or stretched spring upon any object that is attached to it. An object that compresses or stretches a spring is always acted upon by a force that restores the object to its rest or equilibrium position. For most springs (specifically, for those that are said to obey "http://www.physicsclassroom.com/Class/waves/u10l0d.cfm#p2"), the magnitude of the force is directly proportional to the amount of stretch or compression of the spring.http://www.physicsclassroom.com/Class/newtlaws/U2L2b.cfm#Top |
- Part 3: Newton’s Second Law
    
    a doubling of the net force results in a doubling of the acceleration (if mass is held constant).
    
    a *halving* of the net force results in a *halving* of the acceleration (if mass is held constant).
    
    **Acceleration is directly proportional to net force.**
    
    ### **Acceleration is inversely proportional to mass.**
    

Next: 

- Newton’s Third Law
    
    [https://www.physicsclassroom.com/class/newtlaws/Lesson-4/Newton-s-Third-Law](https://www.physicsclassroom.com/class/newtlaws/Lesson-4/Newton-s-Third-Law)
    
- [Vectors - Motion and Forces in Two Dimensions](https://www.physicsclassroom.com/class/vectors)
- **[Momentum and Its Conservation](https://www.physicsclassroom.com/class/momentum)**
- [Work and Energy](https://www.physicsclassroom.com/class/energy)

My documents, 
**Vectors:** 

[https://docs.google.com/document/d/1xRtP7Qk2HUm02xzoNbUZfaAP3Shz1VYXy5_iiUfYm0o/edit](https://docs.google.com/document/d/1xRtP7Qk2HUm02xzoNbUZfaAP3Shz1VYXy5_iiUfYm0o/edit)

**Momentum:** 

[https://docs.google.com/document/d/1SgAtw42tFCTqD7r_fCqUPS7_1e6ed5IMZWVy5bTgQ-A/edit#heading=h.neo3juolarpc](https://docs.google.com/document/d/1SgAtw42tFCTqD7r_fCqUPS7_1e6ed5IMZWVy5bTgQ-A/edit#heading=h.neo3juolarpc)

Newton’s Laws: 

[uncreated] 

Work and Energy 

[uncreated] 

*Note, I am currently interested in working an entry level position in an area related to Unity game design. Please contact me if you hear of any open opportunities. Thank you!* 

- divi
    
    ![profile-divithegamedev-v2-blue.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/profile-divithegamedev-v2-blue.png)
    
    ![profile-divithegamedev-v3.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/profile-divithegamedev-v3.png)
    
    ![profile-divithegamedev-v3-divi.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/profile-divithegamedev-v3-divi.png)
    
    ![profile-divithegamedev-v3-duel.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/profile-divithegamedev-v3-duel.png)
    
    ![profile-divithegamedev-v3-lone-gun.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/profile-divithegamedev-v3-lone-gun.png)
    
    ![profile-divithegamedev-v3-stock.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/profile-divithegamedev-v3-stock.png)
    
    ![divithegamedev-v2.2.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/divithegamedev-v2.2%201.png)
    
    ![divithegamedev-v2.3.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/divithegamedev-v2.3.png)
    
    ![profile-divithegamedev-v2.png](Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db/profile-divithegamedev-v2.png)