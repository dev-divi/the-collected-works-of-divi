# A Voice Control Technique

<aside>
💡 ChatGPT: *This text emphasizes the power of words and the importance of guarding one's speech. It explains that holding one's tongue is a skill that can be developed over time and is crucial for protecting one's life. The text also notes that wise people and fools are not predetermined outcomes, but rather states of consciousness that everyone can embody. By consciously choosing to be silent and only speaking good things, one can transform their heart and eventually become who they want to be. The text suggests that becoming aware of the silence one already has and focusing on pleasant voices can change one's experience of life.*

</aside>

> *A divine verdict is on the lips of a king; his mouth must not betray justice.*
> 

> *Life and death are in the power of the tongue, and those who love it will eat its fruit.*
> 

Words that produce good fruit will become more fruitful, words that produce bad fruit will become that much worse. 

<aside>
💡 There are levels of depth to this,
man is protected when he does not know how powerful his words are.
once man becomes aware of how powerful his words are,
the misuse of those words will cost him dearly.

</aside>

These words are not philosophy, this is describing how it is:

> *"He who guards his mouth and tongue
keeps his soul from distress."*
> 

> *The tongue of the wise adorns knowledge, but the mouth of the fool gushes folly.*
> 

> *Speaking rashly is like a piercing sword, but the tongue of the wise brings healing.*
> 

> *Even a fool is considered wise if he keeps silent, and discerning when he holds his tongue.*
> 

> *As a dream comes through many cares, so the speech of a fool comes with many words.*
> 

> *The words of a wise man’s mouth are gracious, but the lips of a fool consume him.*
> 

> *"A fool’s mouth is his ruin, and his lips are a snare to his soul."*
> 

> *"By your words you will be acquitted, and by your words you will be condemned."*
> 

> *"When words are many, sin is unavoidable, but he who restrains his lips is wise."*
> 

> *"An evil man is trapped by his rebellious speech, but a righteous man escapes from trouble."*
> 

> *He who loves a pure heart and gracious lips will have the king for a friend.*
> 

> *Righteous lips are a king’s delight, and he who speaks honestly is beloved.*
> 

> *Keep your tongue from evil and your lips from deceitful speech.*
> 

> *He who guards his mouth protects his life, but the one who opens his lips invites his own ruin.*
> 

This isn't good advice, this really is the ancient secret. 

You actually will in this lifetime have to guard what comes out of your mouth to protect your own life,
because others will use what you have said and agreed with against you. 

This scripture is not written as what you should do because you ought to. 

The scripture is not really talking about these people and those people, the wise people and the fools, the scripture is talking about a human consciousness. 

You can be the fool and/or you can be the wise, 

neither is a determined outcome.

Everyone is the fool, and everyone can be the wise.

All wise men are also fools.

It is foolish to be wise,

and all wise men are fools in the eyes of fools.

No man alive naturally holds their tongue. 

Holding your tongue is not a gift or a trait,
it is a skill that has to be developed over the course of time.

It is not difficult to develop the skill of guarding your speech as though you are guarding it with your life.

Consciously intend to be silent over time and do not break your silence.

When you have been silent for a while,

You have ample time to consider if you want to speak,

what you are going to speak.

Your speech is no longer reactionary.

If someone says something, you will not respond automatically. 

You are already in silence, so you will choose whether or not it is worth it to break that silence.

> *Even a fool is considered wise if he keeps silent, and discerning when he holds his tongue.*
> 

If your second intention is to only say something if it is good,

then you will only break your silence if you want to speak something good.

Only good things will come out of your mouth.

> *and out of the mouth, the heart speaks.*
> 

Your heart will become good.

---

You will gain from this a second ability and blessing.

You will only say things you want to say,
and eventually, you will only do things you want to do,
and eventually, you will only be who you want to be.

If you are silent, 

you also learn how to listen, 

and if you learn how to listen, 

you can choose to focus on the voices that are pleasant, enjoyable, for you to hear.

You may have already noticed, that you already take a lot of time in silence, you are just not usually conscious of it.
if you become aware of the silence you already have, your awareness grows, you become more conscious.

This is like free money, 

and an intention to apply this will change your experience of life. 

---

### ChatGPT:

<aside>
💡 *“The ancient scripture teaches us that guarding our speech is a crucial aspect of protecting our souls from distress. The tongue of the wise is adorned with knowledge, while the mouth of the foolish spouts folly. Speaking recklessly is like using a sharp sword, but wise speech brings healing. Even a fool can be considered wise if they remain silent and discerning.

The scripture is not meant to be taken as a strict commandment, but as a reflection of human consciousness. We all have the capacity to be wise or foolish, and no one is predetermined to be one or the other. All wise men are also foolish, and it is foolish to always be wise in the eyes of others.*

*Holding your tongue is not a natural gift, but rather a skill that must be developed over time. It is essential to consciously intend to remain silent and resist the urge to react immediately to others. When we are silent, we have time to consider whether what we want to say is worth breaking our silence.*

*If we make a conscious intention to only speak good things, then only good things will come out of our mouth. Our heart will become good as a result. Learning to listen is also an essential aspect of remaining silent, and it allows us to focus on pleasant and enjoyable voices.*

*Becoming aware of the silence we already have can make us more conscious and change our experience of life for the better. It is a skill that can be developed and will benefit us greatly in our interactions with others.”*

</aside>