# Radical Self-Compassion

****

### Why is self-compassion so widely advised, yet seldom seen or applied in life?

- Not many living people know how to practice self-compassion.
- Words of self-compassion are not agreeable to what this world believes.

**A new commitment to self compassion:**

> I bind the compassion of spirit to my soul.
I allow compassion in to every mistake that I make.
I allow compassionate understanding into every failure that I make.
> 

One of life's true secret concepts is that if everything happens to
teach you a lesson, if you learn the lesson, then there is no reason
for that to continue happening to you any longer.
Then, what is the lesson of failure?
What if the lesson of failure was to be compassionate?

---

**Mending relations with self:**

> I repent for judging you. I am sorry for judging you.  
I understand you and you have worth as a human being.  
You are deserving of compassion, and kindness.  
I am sorry for falsely judging that you were not worthy of having joy.  
I repent for falsely judging that you are not worthy of having joy.  
I am sorry for hating you.  
I repent for hating you. 
I love and understand you.  
I am sorry for withholding love and compassionate understanding from you.  
I repent for withholding love and compassionate understanding from you.  
I allow you, I allow in love and compassionate understanding to you.  
I am sorry for judging your toxic feelings.  
I am sorry for hating your toxic and undesirable and unwanted feelings and experiences.  
I let go of my judging of you.  I am not the one worthy of judging you.  
I repent for my false idea that I was worthy of judging you.  
I forgive you. I wish well for you. I care about you.  I bless you. I wish you well. 
I agree to this.
> 

---

> I am sorry for falsely judging you for not being enough.  
I repent for falsely judging you for not being enough.  
I repent for wrongly joining and agreeing with others in judging you.
> 

*There are apologies you would make to a friend if you were to believe you wronged them. 
Make the apologies to yourself if you believe you have wronged yourself.*