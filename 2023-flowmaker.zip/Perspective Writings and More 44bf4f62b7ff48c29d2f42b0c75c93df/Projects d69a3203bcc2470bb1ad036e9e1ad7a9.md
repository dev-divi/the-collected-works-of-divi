# Projects

[Pocket Mirror](https://play.unity.com/mg/other/webgl-builds-180855) - My first videogame (2022)

[The Magic of Potentiality](https://www.amazon.com/dp/B09NTT8PN1) - My first published book (2021)

[SorceRawr](https://sorcerawr.com/) - Entertainment + Resource website (2021)

[A Mystery Cubes Club!](https://amysterycubesclub.com/) - 412 WebGL Animated Cubes (2021)

[LightDark.art](https://lightdark.art/) - Interactive Text project (2021)

[Scripture Entropy Generator](https://divinescripture.art/index.html) (2021)

[Project Goals](Projects%20d69a3203bcc2470bb1ad036e9e1ad7a9/Project%20Goals%20bc1dec4909c3469bb820801fa1b3304a.csv)