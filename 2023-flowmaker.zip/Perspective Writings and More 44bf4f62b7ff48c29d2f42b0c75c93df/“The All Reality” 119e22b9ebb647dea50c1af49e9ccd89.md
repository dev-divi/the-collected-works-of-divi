# “The All Reality”

I have described this reality in many ways, one of them being as so, 
*”In that reality which is coming, 
there is only perfection, infinite and instant revelation of meaning, infinitely meaningful experiences that come at a rate of perfect flow from one to the next, all good things of reality come together such as family and connection, there is no suffering, there is nothing but fulfillment and miracles and possibilities of destiny transpiring, 
there is no darkness, no fear, no injury, 
that's all on the outside, 
on the inside there is infinite healing of all wounds, there is the pure and perfect person that is complete and loved, a life which is a celebration of the miracle of existence itself. 

The way this happens makes it a definitive outcome that all realities dissolve into the actual Reality. 
This is because when Reality comes, 
it is like a wave of truth which evaporates any untruth that had appeared before it.”*