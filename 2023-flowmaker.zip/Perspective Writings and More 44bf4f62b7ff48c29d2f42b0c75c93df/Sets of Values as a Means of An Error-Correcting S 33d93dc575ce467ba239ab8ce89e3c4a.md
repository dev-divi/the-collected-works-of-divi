# Sets of Values as a Means of An Error-Correcting System

### The concept of having a set of values involves a relationship with our internal 'error-correcting systems'.

The implication of applying values to your life is that you trust in the results of those values,

and as you expect results, you expect that the amount of errors you make will be reduced,

in comparison to if you did not hold those values.

The concept is that if you lean into certain good values, then things will go good for you.

The more virtuous you become, the better your results, and the less errors you make.

As you make less errors, this means you get to rest your error-detection systems,

because you trust in the values that the virtues are based on.

> `A virtue is a trait of excellence, including traits that may be moral, social, or intellectual. The cultivation and refinement of virtue is held to be the "good of humanity" and thus is valued as an end purpose of life or a foundational principle of being.`
> 

The consideration of the modern day is brought up in certain lyrics and statements noticed,

such as this line from this song, 'The Internet',

*`'Apathy's a tragedy, and boredom is a crime'`*

This lyric stands out to people. Why? It has surface level implications, but it also raises a critical concern that there could be an error.

It arises the possibility that there could be an error made with a virtue itself. This is not mentally understood, it is simply felt as an emotional pain.

A comfort of society is that it gives you virtues that you can trust, you can trust society to tell you what is held to be the good of humanity, the traits of excellence. It is a simple process, you can trust society to give you virtues, you can trust the virtues to prevent you from error.

However, once your error detection systems recognize that there can be an error in the virtue presented to you by society, you instantly recognize that all actions taken from holding that false virtue will be error-prone, full of errors.

This recognition is the awareness that turning off your error-detection system from assessing the virtues you acquire is not actually safe in this world,

that is a kind of ignorance that can cause negative consequences to your life, not benefits.

While mankind is not paying attention, anyone who is paying attention can create false virtue to further their ends.

This harms a person, because in their heart and in their welfare they can incur damages.

### Anything can be a false virtue, and false virtues do not have to be extreme.

A false virtue could be extreme, such as that gluttony is the apex of human evolution and the standard that all should be defined by.

### More common, is far more subtle false virtues.

They are tiny, seemingly inconsequential, you might not notice that they don't sound quite right. You might feel that something is off.

Most of these being created now are related to a lifestyle which involves a cooperation with corporations, that is, in which business operations run smoothly.

It is such that humans are being taught to get along and tolerate each other, not in such a way that they care for one another, but in such a way that business runs smoothly without problems, without visible errors.

However, if there is a flaw in the virtue itself, there may be serious errors manifesting in a person's life.

As said before, anything can be an example. A false virtue could be created to support deception, or to support overwork, or spending habits.

Once you extend this beyond corporate interests and extend to an unconscious culture, there are two more possibilities.

The first is the creation of bad ethics. "You shouldn't do that." "You should do that."

Some of these bad ethics support a culture of victimhood in which it is taught to be inappropriate to *have a spine'*, to ‘*ruffle feathers’* to display any unexpected behavior. Other bad ethics might just simply be insane if you actually stop and look at them, these are often politically motivated, terrible ideas.

The second is in regards to group behavior. These usually arise during periods of increased emotion in society, where people are so stirred up that they do not recognize exactly what they are doing. This is when a group might find it perfectly reasonable to say, commit genocide of a race.

It might be something like, seeing someone attempt to help someone, and killing that person instead.

Luckily, false virtues are easy for us to recognize from the outside. The more detached we are from a group, the easier it is to observe errors.

It is the ones we have already internalized that have bypassed our systems and can cause harm without our notice.

When looking at the world with this, it is common for man to say, "Man cannot be trusted."

This is followed by a loss of faith in humanity.

The two common reactions to this are either an indifference of humanity, not caring at all,

or a decision that man is incompetent and it is unsafe to leave him on his own, therefore one should step in and command man by force.

### **How do you determine real virtue from false virtue?**

Externally, be aware of what you hear, and know that what sounds good may hold error.

Internally, to determine real virtue, you have to develop a relationship with yourself. You have to develop a relationship with goodness, to know its attributes and character, what it is, and what it is not. You have to understand good as it exists.

There could be no greater weapon formed against you then to make you believe that there is simply no good,

and therefore, any virtue, real or false, is of equal measure.

There are first steps to making a person malleable to new ideas for the purposes of control,

and they all involve causing the person to adopt a certain belief system in which there is no value,

and as such, there is no meaning to whether or not the person is manipulated by outside forces.

The less you believe you matter, the less value you believe you have, the more willing you are going to be to follow ideas that are destructive to your health,

for the benefit of another's interests.

**What are some examples of false virtues you see in the modern world?**

---

Anonymous: *I suppose it depends on 'your' view on the difference between real and false virtue.*

*The meaning successful can be different for everyone,* 

*if my mind has peace, I would say that I am successful.* 

The concept here is that real virtue is not an interpersonal *'view'.*
There is that which harms you, regardless of your 'view',
you can deceive yourself, but it does not change what is.

The example you present is an example that there could be a false virtue of success presented in which the 'success' is actually a negative,
as opposed to a real success in which it is a success, by the meaning of the word success, a victory.

It seems we do not actually have a unique experience, I experience hatred and love the same as the next person,
grief is grief, loss is loss, joy is joy,
these experiences are not unique nor do they change person by person, they are constants.

The concept here is that real virtue is not an interpersonal 'view' there is that which harms you, regardless of your 'view', you can deceive yourself, but it does not change what is. the example you present is an example that there could be a false virtue of success presented in which the 'success' is actually a negative, as opposed to a real success in which it is a success, by the meaning of the word success, a victory. 

Anonymous: ***So in your view, virtue is not subjective but objective?*** 

**Absolutely.** 

Hmm I understand it now, success may have negative consequences, and that certain actions or behaviours may be harmful no matter what.

**Yes, exactly.**

True virtue could be measured on a scale up to perfection,

Based on the world's definition,
*"a good of humanity",*
Then the highest measure would be that which benefits all humanity,
Such as an action which benefits oneself and all others.

It seems that when man cannot figure out perfection, he compromises with such a delusion of an idea, such like that the answer may be subjective.
There's nothing subjective about it.

A person's individual values would land their virtues somewhere on the measure of real virtue, 

reduced down to the simple understanding that there does exist actions or behaviors which are harmful no matter what,
Another way to say it is that you can sugarcoat illness and disease, malice and mistreatment, but no sugarcoating will change what it is.