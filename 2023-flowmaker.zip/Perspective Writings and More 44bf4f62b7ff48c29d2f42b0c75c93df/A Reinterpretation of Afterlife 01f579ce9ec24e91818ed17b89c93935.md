# A Reinterpretation of Afterlife

I believe there is a misinterpretation of hell. 

The fire of hell is also the fire of heaven. The fire of hell is the exposure to Reality. It burns up everything that is not perfect. 
Every time you experience any kind of healing through god, fire burns out the wounds within you. 
It is true that if there is nothing good in a person, when the fire comes, by definition there will be nothing left of that person. 

To say this again, all of your imperfections and weaknesses doubts fears failures everything that is not of real life is absorbed into real life, what actually exists. 

This is why meditation is on such a great track is it at least gets in tune with what actually exists, 
however that does not mean the meditator is in contact with that Reality.