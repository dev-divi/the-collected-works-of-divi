# Crypto: The Metaphor to Artificiality

Crypto is the greatest technology that exists as a metaphor to man's creation of Artificiality.

When I say Artificial, I am repurposing this word with a new context for the purpose of this writing. The main meaning of Artificial here is Substitution, a substitute for something else.
When I say Real and Artificial, the true words I am referring to are good and evil, respectively,
but not as man thinks of these.
I am not referring to Artificial as a moral wrong.
This is why I do not want to use the word evil here.
When I say evil, what I mean is not "bad", what I mean is, "false".
When I say false, I mean that in the sense that there is an error. If I run a program and ask it to say "apple", and it instead returns, "banana",
I say that program has an error.
So when I say Artificial, I mean error.
That is,
Artificial / Substitution > evil > false > error.

If I run a program which I intend to arrive at a desired solution, if there is an error in the program, it will not arrive at the desired solution.
The program will output a different solution,
a substitution for the original solution.

This is man's thinking, in which there is an error in the program, and the desired outcome, the result, is far different than what he expected.

Crypto technology is a hedge against eternity.
This statement in itself is not rational.
Eternity cannot be hedged against,
but crypto is an attempt to hedge against something that you cannot even contact, it is not there for you to bargain with,
it does not even know you are there, attempting to bargain with it.

All things begin with how we think about things, the problems we see and try to solve.

There are major human developments and technologies which all originate from the same error in the original logic, though with each of these developments the same error becomes more clear. There will be future technology that is far more clear that I will discuss.

I am not saying this is historical, though I want to emphasize how this kind of thinking can begin.

Humans created sacred spaces, places to honor that which reflected the value they saw in the eternal world.
It is possible that their descendents found value in these sacred spaces, and attempted to preserve them.
A while later, the 'great spirit' is upon people and so they create a church to reflect the value they have in this experience.
However, the experience leaves, and now these people are in an empty church.
It is possible that their descendents now see value in the church itself, never knowing of that which it once attempted to reflect.

A house is built, and other houses are built, and it would be great to keep these houses from falling down, but some personalities come and they just love tearing down houses.
The people who want to keep the houses have to create a solution to keep their house built.

It is not possible to keep anything in reality, everything changes, even you change and then you die.

We want to keep the house standing, but the same person has come by many times and torn down the house many times.
He tells us he will never tear down the house again,
then the next day he comes and tears down the house again.
It took time and effort to build the house each time, and now we are getting tired of this.

A few houses then get together to create a solution. Well, if a person tears down a house,
then we simply kill him, then he can never tear down a house again.

On what authority do they base this claim on?
How do they know he will tear down the house again?
They do not know. They have no authority.
So they create a solution. The solution is the concept of evidence.
This is the original error.
This original error is born from the concept of knowing what you cannot know.

From evidence, the authority on which these people have based their claim is the past.
The past, as you have heard said a thousand times, is not real, it does not exist.
To base your evidence on that which does not exist, this is madness, this is not sanity.
You will never know what this man who has torn down houses will do next, he is unpredictable,
and the only way you can predict his actions is if you restrict his absolute autonomy.

The only way you can more reliably predict the actions that this man will take is if you can constrict the actions he is available to take,
if you make it more difficult for him to take free action, or if you kill him.
Man's absolute autonomy in free choice cannot be stopped, this is impossible. You cannot stop him from doing anything, not even if you bind him and tie his hands.
If he wishes to escape and knows he can escape, he can.
There is the possibility that you can trap someone into a 'point of no return' scenario, and this is our fundamental human understanding of an act of true evil.
This is why there are certain outcomes we understand as pure evil, an example is the worst of these being known as "that file" on the public Internet.
To kidnap a person and enslave them to be under your control for your enjoyment is one of the worst forms of evil that man has known in this world.
This is because of the dehumanization of a person necessary to completely restrict their independence of choice.
In all of these scenarios, whether or not the person escaped, there is always the "knowing" that comes from the intuition of that point of no return, and the option is available to escape it.
I personally know a person who was in this scenario, had that point of decision making, and had made the decision to escape that outcome. She was featured on CNN and nationwide.
Even those who are in prison are able to escape, in any number of stories you can look up.
This means the only reliable way that you can restrict an inviduals complete autonomy is if you either kill them,
or condition them to believe that they cannot escape.
You cannot stop them, but you can attempt to influence their thinking until they believe that they can be stopped.

It is from all of this that a justice system is created. A justice system takes a majority rule and attempts to control the autonomy of those not in that majority rule.
This is created based on a system of evidence, on the authority of the past, that what a person has done in the past has given you the authority to restrict their autonomy
to prevent them from the ability to choose to make a choice again.

Governments and eventually totalitarian governments are eventually created based on this justice system, in order to govern a people.

This is one of the three parts in the error of human thinking, the first being the misplacement of value in man's own creations, the second being the belief in the existence of the past, and the third being the belief that you can indefinitely perpetuate something in the physical world by means of the past.

This third belief is the foundation of government, and what would lead to the evolution of government, the creation of a company or corporation, a legacy. This is all to attempt to establish a fortress which cannot be destroyed. A company is perpetuated not by a building, but by an idea. If the idea is sustainable, the company can continue
to exist for a while, as all ideas exist whether or not there is a company to represent them. An idea is not enough, you have to create a convincing argument that you have
the authority to perpetuate that idea. The authority man uses to keep a company established is again, the authority of the past.
The evidence used to stand on the authority of the past in a company is by means of agreement.
If man agrees when two or three are gathered, it shall be done in the midst of them.
The authority of the past a company stands on is by the use of a recording of that agreement, which is known as a contract.
As man's ultimate authority is in his word and his name, a contract seeks to make a record of the agreement made with a man's word and his name.
If a man signs a contract, he has exercised the power of his free choice, he has used his power of creation to agree with the idea laid out in that contract,
whether or not that idea will remain true in the future.
This means that by signing that contract, the man may have participated in using his authority in false thinking, into that which he cannot know.
If man signs a contract which says that he will never do certain things, he is participating in a fraudulence, because who knows what he will do in the future?
Who he will be in the future is unknown. No one knows this, not even him.
If he is committed to an idea, then perhaps by agreeing, he believes that this idea will remain true.

The next major advancement we have is artificial intelligence, and this may supercede even blockchains in the metaphor of the fallacy of human error thinking,
that to perpetuate many borrowed and old ideas is an adequate substitute for organic or new intelligence.
Artificial intelligence is the perfect metaphor for man's unconsciousness, crypto technology is the perfect metaphor for the error in man's thinking.

Crypto technology is the evolution of justice, the evolution of government, and the evolution of corporations. This is an extended attempt to perpetuate an idea by means
of a system which uses a record of the past in order to determine authority. This system is far more equipped to stand on the authority of the past,
as well as to control the autonomy of other independent actors and restrict their freedom of choice by means of their belief in the system and agreement with that system,
and the perpetuation of that system by means of those with control.
Governments once stood with religion, and the ideas and belief religion allowed them to perpetuate.
Companies are far more evolved in government because they introduce a spiritual dimension of the power of human creation to the perpetuation of their structures on the physical plane. These employ some of the unlimited power we possess with the power of creation, by means of techniques such as symbols and logos, even art, to perpetuate an idea.
The successful implementation of this is the employment of what exists in possibility in the invisible realm.
This is from deep occult understandings of the nature of thought.
This is the understanding that if a certain amount of will and power is applied to thought, a thought can leave the realm of an individual's control and play itself out on its own. There are levels to this, which lead up to the creation of a god, a thought which exists in the thought realm and now acts out the intentions of the person who created it.
You can understand this if you understand a computer program, you write the program, start the program, and now the program runs according to the intentions of its programming without your direct influence.
A company creates a thought in the thought realm which takes on a life of its own.

This is where totalitarian governments fail, eventually the freedom of choice inherent in human beings and the fundamental fight against oppression will create a resistance that will destroy that government. These governments are not backed by the power of will in that invisible thought realm.

A company can also fail even if that thought is brought into the thought realm, because contracts are not enough, they require your belief. The 'thought mind' of the company itself does not have the necessary hands and feet to allow it to operate fully in the physical realm.

This is where crypto technology comes in, where a system has far more ability to exercise large scale movement in the physical realm, the programs created have the hands and legs necessary to create change in the physical world, and the structure necessary to perpetuate itself without anyone being able to independently shut it down.

Again, crypto technology can succeed where totalitarian governments fail, this creates structures that can perpetuate for far longer than the people who originally created them.

There is now possible a synthesis of these technologies that will allow for a length of human oppression never before possible in the physical world,
the synthesis of artificial intelligence and crypto technology.
This will allow for a system to be constructed with the intentions of its creator, with a structure that can exist for as long as there is enough electricity to power the machine. The problem with governments is that people get old and die, leaders get old and die, their children may not be as equipped to run the show.
Once one of these artificially intelligence crypto systems is introduced to a region, this will allow a system of oppression to perpetuate for many centuries after its original creators have died. This means the period of darkness -- that period in which freedom of choice is restricted -- between a time of oppression and a resistence of freedom will be significantly longer.

This is a hedge against eternity, the usage of the authority of the past to establish a system to exercise control over the physical world.
Eternity cannot be hedged against as you neither stop the day when the electricity goes out, nor can you stop the incoming of new and fresh thought into human minds,
a natural process of existence. You can only temporarily distract minds from new and fresh organic thought.

This also may be a reason that Christ did not speak when he was arrested. What could he possibly say? If he says, "What are these things you are speaking of that I have done in the past, that is not me, there is no past, I am standing right here in front of you", they will not even understand him. There is nothing to be said.
It is no use saying, "On what authority do you accuse me?" He knows their authority is based on a false authority, there is no point in reasoning with them.