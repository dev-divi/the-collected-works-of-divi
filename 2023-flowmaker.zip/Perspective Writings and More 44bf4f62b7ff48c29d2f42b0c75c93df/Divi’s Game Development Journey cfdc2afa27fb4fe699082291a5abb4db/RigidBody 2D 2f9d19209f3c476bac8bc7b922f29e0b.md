# RigidBody 2D

Rigidbody physics component for 2D sprites.

The Rigidbody2D class essentially provides the same functionality in 2D that the Rigidbody class provides in 3D. Adding a Rigidbody2D component to a sprite puts it under the control of the physics engine. By itself, this means that the sprite will be affected by gravity and can be controlled from scripts using forces. By adding the appropriate collider component, the sprite will also respond to collisions with other sprites. This behaviour comes entirely from Unity's physics system; very little code is required to get impressive and authentic physical behaviour and allows for "emergent" gameplay that was not explicitly coded into the game.

See Also: [Rigidbody](https://docs.unity3d.com/ScriptReference/Rigidbody.html) class, [SpriteRenderer](https://docs.unity3d.com/ScriptReference/SpriteRenderer.html) class, [Collider2D](https://docs.unity3d.com/ScriptReference/Collider2D.html) class, [Joint2D](https://docs.unity3d.com/ScriptReference/Joint2D.html) class.

### **Properties**

| https://docs.unity3d.com/ScriptReference/Rigidbody2D-angularDrag.html | Coefficient of angular drag. |
| --- | --- |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-angularVelocity.html | Angular velocity in degrees per second. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-attachedColliderCount.html | Returns the number of Collider2D attached to this Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-bodyType.html | The physical behaviour type of the Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-centerOfMass.html | The center of mass of the rigidBody in local space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-collisionDetectionMode.html | The method used by the physics engine to check if two objects have collided. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-constraints.html | Controls which degrees of freedom are allowed for the simulation of this Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-drag.html | Coefficient of drag. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-excludeLayers.html | The additional Layers that all Collider2D attached to this Rigidbody2D should exclude when deciding if a contact with another Collider2D should happen or not. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-freezeRotation.html | Controls whether physics will change the rotation of the object. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-gravityScale.html | The degree to which this object is affected by gravity. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-includeLayers.html | The additional Layers that all Collider2D attached to this Rigidbody2D should include when deciding if a contact with another Collider2D should happen or not. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-inertia.html | The Rigidbody's resistance to changes in angular velocity (rotation). |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-interpolation.html | Physics interpolation used between updates. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-isKinematic.html | Should this rigidbody be taken out of physics control? |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-mass.html | Mass of the Rigidbody. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-position.html | The position of the rigidbody. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-rotation.html | The rotation of the rigidbody. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-sharedMaterial.html | The PhysicsMaterial2D that is applied to all Collider2D attached to this Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-simulated.html | Indicates whether the rigid body should be simulated or not by the physics system. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-sleepMode.html | The sleep state that the rigidbody will initially be in. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-totalForce.html | The total amount of force that has been explicitly applied to this Rigidbody2D since the last physics simulation step. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-totalTorque.html | The total amount of torque that has been explicitly applied to this Rigidbody2D since the last physics simulation step. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-useAutoMass.html | Should the total rigid-body mass be automatically calculated from the [[Collider2D.density]] of attached colliders? |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-useFullKinematicContacts.html | Should kinematic/kinematic and kinematic/static collisions be allowed? |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-velocity.html | Linear velocity of the Rigidbody in units per second. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D-worldCenterOfMass.html | Gets the center of mass of the rigidBody in global space. |

### **Public Methods**

| https://docs.unity3d.com/ScriptReference/Rigidbody2D.AddForce.html | Apply a force to the rigidbody. |
| --- | --- |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.AddForceAtPosition.html | Apply a force at a given position in space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.AddRelativeForce.html | Adds a force to the rigidbody2D relative to its coordinate system. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.AddTorque.html | Apply a torque at the rigidbody's centre of mass. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.Cast.html | All the Collider2D shapes attached to the Rigidbody2D are cast into the Scene starting at each Collider position ignoring the Colliders attached to the same Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.ClosestPoint.html | Returns a point on the perimeter of all enabled Colliders attached to this Rigidbody that is closest to the specified position. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.Distance.html | Calculates the minimum distance of this collider against all Collider2D attached to this Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetAttachedColliders.html | Returns all Collider2D that are attached to this Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetContacts.html | Retrieves all contact points for all of the Collider(s) attached to this Rigidbody. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetPoint.html | Get a local space point given the point point in rigidBody global space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetPointVelocity.html | The velocity of the rigidbody at the point Point in global space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetRelativePoint.html | Get a global space point given the point relativePoint in rigidBody local space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetRelativePointVelocity.html | The velocity of the rigidbody at the point Point in local space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetRelativeVector.html | Get a global space vector given the vector relativeVector in rigidBody local space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetShapes.html | Gets all the PhysicsShape2D used by all Collider2D attached to the Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.GetVector.html | Get a local space vector given the vector vector in rigidBody global space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.IsAwake.html | Is the rigidbody "awake"? |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.IsSleeping.html | Is the rigidbody "sleeping"? |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.IsTouching.html | Checks whether the collider is touching any of the collider(s) attached to this rigidbody or not. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.IsTouchingLayers.html | Checks whether any of the collider(s) attached to this rigidbody are touching any colliders on the specified layerMask or not. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.MovePosition.html | Moves the rigidbody to position. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.MoveRotation.html | Rotates the Rigidbody to angle (given in degrees). |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.OverlapCollider.html | Get a list of all Colliders that overlap all Colliders attached to this Rigidbody2D. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.OverlapPoint.html | Check if any of the Rigidbody2D colliders overlap a point in space. |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.SetRotation.html | Sets the rotation of the Rigidbody2D to angle (given in degrees). |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.Sleep.html | Make the rigidbody "sleep". |
| https://docs.unity3d.com/ScriptReference/Rigidbody2D.WakeUp.html | Disables the "sleeping" state of a rigidbody. |

### **Inherited Members**

### **Properties**

| https://docs.unity3d.com/ScriptReference/Component-gameObject.html | The game object this component is attached to. A component is always attached to a game object. |
| --- | --- |
| https://docs.unity3d.com/ScriptReference/Component-tag.html | The tag of this game object. |
| https://docs.unity3d.com/ScriptReference/Component-transform.html | The Transform attached to this GameObject. |
| https://docs.unity3d.com/ScriptReference/Object-hideFlags.html | Should the object be hidden, saved with the Scene or modifiable by the user? |
| https://docs.unity3d.com/ScriptReference/Object-name.html | The name of the object. |

### **Public Methods**

| https://docs.unity3d.com/ScriptReference/Component.BroadcastMessage.html | Calls the method named methodName on every MonoBehaviour in this game object or any of its children. |
| --- | --- |
| https://docs.unity3d.com/ScriptReference/Component.CompareTag.html | Checks the GameObject's tag against the defined tag. |
| https://docs.unity3d.com/ScriptReference/Component.GetComponent.html | Gets a reference to a component of type T on the same GameObject as the component specified. |
| https://docs.unity3d.com/ScriptReference/Component.GetComponentInChildren.html | Gets a reference to a component of type T on the same GameObject as the component specified, or any child of the GameObject. |
| https://docs.unity3d.com/ScriptReference/Component.GetComponentInParent.html | Gets a reference to a component of type T on the same GameObject as the component specified, or any parent of the GameObject. |
| https://docs.unity3d.com/ScriptReference/Component.GetComponents.html | Gets references to all components of type T on the same GameObject as the component specified. |
| https://docs.unity3d.com/ScriptReference/Component.GetComponentsInChildren.html | Gets references to all components of type T on the same GameObject as the component specified, and any child of the GameObject. |
| https://docs.unity3d.com/ScriptReference/Component.GetComponentsInParent.html | Gets references to all components of type T on the same GameObject as the component specified, and any parent of the GameObject. |
| https://docs.unity3d.com/ScriptReference/Component.SendMessage.html | Calls the method named methodName on every MonoBehaviour in this game object. |
| https://docs.unity3d.com/ScriptReference/Component.SendMessageUpwards.html | Calls the method named methodName on every MonoBehaviour in this game object and on every ancestor of the behaviour. |
| https://docs.unity3d.com/ScriptReference/Component.TryGetComponent.html | Gets the component of the specified type, if it exists. |
| https://docs.unity3d.com/ScriptReference/Object.GetInstanceID.html | Gets the instance ID of the object. |
| https://docs.unity3d.com/ScriptReference/Object.ToString.html | Returns the name of the object. |

### **Static Methods**

| https://docs.unity3d.com/ScriptReference/Object.Destroy.html | Removes a GameObject, component or asset. |
| --- | --- |
| https://docs.unity3d.com/ScriptReference/Object.DestroyImmediate.html | Destroys the object obj immediately. You are strongly recommended to use Destroy instead. |
| https://docs.unity3d.com/ScriptReference/Object.DontDestroyOnLoad.html | Do not destroy the target Object when loading a new Scene. |
| https://docs.unity3d.com/ScriptReference/Object.FindAnyObjectByType.html | Retrieves any active loaded object of Type type. |
| https://docs.unity3d.com/ScriptReference/Object.FindFirstObjectByType.html | Retrieves the first active loaded object of Type type. |
| https://docs.unity3d.com/ScriptReference/Object.FindObjectOfType.html | Returns the first active loaded object of Type type. |
| https://docs.unity3d.com/ScriptReference/Object.FindObjectsByType.html | Retrieves a list of all loaded objects of Type type. |
| https://docs.unity3d.com/ScriptReference/Object.FindObjectsOfType.html | Gets a list of all loaded objects of Type type. |
| https://docs.unity3d.com/ScriptReference/Object.Instantiate.html | Clones the object original and returns the clone. |

### **Operators**

| https://docs.unity3d.com/ScriptReference/Object-operator_Object.html | Does the object exist? |
| --- | --- |
| https://docs.unity3d.com/ScriptReference/Object-operator_ne.html | Compares if two objects refer to a different object. |
| https://docs.unity3d.com/ScriptReference/Object-operator_eq.html | Compares two object references to see if they refer to the same object. |