# Study Unity Physics Rigidbody

status: Not started