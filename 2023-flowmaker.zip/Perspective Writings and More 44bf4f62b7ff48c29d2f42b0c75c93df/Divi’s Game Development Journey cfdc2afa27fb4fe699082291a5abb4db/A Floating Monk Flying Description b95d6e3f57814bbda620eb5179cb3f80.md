# A Floating Monk Flying Description

```markdown
A Floating monk flying 

This floating monk is on a relaxing, reinvigorating trip as he soars over rooftops, bounces above the surface tensions of the planet, and speeds through mind-bending warp gates. 
 
He's flying through the skys. He has no enemies. He has no problems. 
Become the monk. Let go. Sail away.
```