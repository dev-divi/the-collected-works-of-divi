# in gimp when scaling sprites set interpolation to off

Tags: gimp