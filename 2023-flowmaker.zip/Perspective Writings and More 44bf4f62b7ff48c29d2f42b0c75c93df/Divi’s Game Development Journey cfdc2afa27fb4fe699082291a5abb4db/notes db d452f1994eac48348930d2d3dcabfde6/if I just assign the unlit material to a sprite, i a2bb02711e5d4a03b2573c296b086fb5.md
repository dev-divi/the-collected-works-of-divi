# if I just assign the unlit material to a sprite, i might be able to avoid setting up each sprite that I don’t want to cast lighting on

Tags: 2d dev