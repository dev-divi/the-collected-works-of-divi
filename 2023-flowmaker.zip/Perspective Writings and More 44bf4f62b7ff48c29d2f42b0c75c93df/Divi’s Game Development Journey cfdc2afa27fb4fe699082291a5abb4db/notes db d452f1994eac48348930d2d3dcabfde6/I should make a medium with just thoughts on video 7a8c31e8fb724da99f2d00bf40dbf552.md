# I should make a medium with just thoughts on videogames. not as a big effort just as an output to have available. call it divimakesvideogames

Tags: gaming