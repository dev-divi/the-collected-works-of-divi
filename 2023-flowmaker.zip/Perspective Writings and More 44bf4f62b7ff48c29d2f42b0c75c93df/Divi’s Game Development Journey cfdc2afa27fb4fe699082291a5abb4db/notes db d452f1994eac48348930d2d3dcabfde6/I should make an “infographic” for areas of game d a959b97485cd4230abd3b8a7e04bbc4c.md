# I should make an “infographic” for areas of game design, highlighting my current exposure to that concept in color. then I can map out everything I know and don’t know. I can make one for 2D to get started and use the concepts outlined in the book.

Tags: Development