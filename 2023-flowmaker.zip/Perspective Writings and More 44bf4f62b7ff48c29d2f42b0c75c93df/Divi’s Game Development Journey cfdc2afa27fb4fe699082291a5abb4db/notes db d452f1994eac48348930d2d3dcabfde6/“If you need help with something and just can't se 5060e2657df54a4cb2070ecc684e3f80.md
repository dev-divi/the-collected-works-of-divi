# “If you need help with something and just can't seem to find the answer online, try using chatGPT for help. It's insane how good that AI is at coding.”

Tags: anonymous author