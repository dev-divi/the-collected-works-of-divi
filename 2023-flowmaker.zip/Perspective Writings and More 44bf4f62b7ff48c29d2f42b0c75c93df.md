# Perspective Writings and More

![divithegamedev-v2.2.png](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/divithegamedev-v2.2.png)

**I seek to share the ultimate perspective of life.**

An eternal student and teacher, I enjoy building and writing. 

---

# Perspective

[Getting closer to the real you](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Getting%20closer%20to%20the%20real%20you%2002168182aa9347f2922b9de019860a11.md)

[The righteousness of the future is not the righteousness of today.](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%20righteousness%20of%20the%20future%20is%20not%20the%20righteo%20501c452f87134467916b94b941323940.md)

[Love in Life ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Love%20in%20Life%20badede2335c4495da060a03f8b455e33.md)

[FLOWMAKER’s Perspective and Glossary](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/FLOWMAKER%E2%80%99s%20Perspective%20and%20Glossary%2040c6b726d140473aa24fd3a542dff6b0.md)

[Perfect Flow State](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Perfect%20Flow%20State%2002df759021d44cda8e63b4148aa07f99.md)

[“The All Reality”](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/%E2%80%9CThe%20All%20Reality%E2%80%9D%20119e22b9ebb647dea50c1af49e9ccd89.md)

[The Real You ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%20Real%20You%20cac48ff4bc0a4d6d93e96e90c35e43f8.md)

[The Real You is a Totality  ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%20Real%20You%20is%20a%20Totality%203b7b4b0c99474520abb8ca1a42c3f59e.md)

[What is Light? ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/What%20is%20Light%20e81a56fe4ff54dcb8502be0c80f6607a.md)

[Question Clarity](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Question%20Clarity%20c43e57efeb2e4a1ea3e987f50f20f3a6.md)

[Divinie’s ‘Who is God’ ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Divinie%E2%80%99s%20%E2%80%98Who%20is%20God%E2%80%99%20cdebf02c8cfe4ff1986a7c88addcd25c.md)

[Divinie’s ‘Who is the Father?’ ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Divinie%E2%80%99s%20%E2%80%98Who%20is%20the%20Father%20%E2%80%99%20e77bc1dc9c664596927ea9839da1c0a2.md)

[Divinie’s ‘Desire’ ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Divinie%E2%80%99s%20%E2%80%98Desire%E2%80%99%207668a835bcbd485e9e1602fa25c327a0.md)

[Divinie’s ‘The Network’](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Divinie%E2%80%99s%20%E2%80%98The%20Network%E2%80%99%20e6dd933ee4e44ce292f968dd10ad07c0.md)

[Divinie’s ‘What is Way?’](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Divinie%E2%80%99s%20%E2%80%98What%20is%20Way%20%E2%80%99%206b988989bfb44eb9999d6c6758bd4840.md)

[God Doesn’t Need You? ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/God%20Doesn%E2%80%99t%20Need%20You%206087047d96f34617a764b52335b628e0.md)

[Do you know who you are?](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Do%20you%20know%20who%20you%20are%203463ca2e40b346f0a5cf9a8e96a3363a.md)

[A Different Pursuit ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/A%20Different%20Pursuit%200d807a95da9f45ce93356c9a00f0c1b1.md)

---

# Writings

[Mysticism: Love Still Unknown ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Mysticism%20Love%20Still%20Unknown%207a854bd1a42549508100c019e71c1e55.md)

[Sets of Values as a Means of An Error-Correcting System](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Sets%20of%20Values%20as%20a%20Means%20of%20An%20Error-Correcting%20S%2033d93dc575ce467ba239ab8ce89e3c4a.md)

[A Voice Control Technique ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/A%20Voice%20Control%20Technique%2078d94b0f6f3f4f4190403ef2cbb41fc2.md)

[The Outcome of Consciously Creating Reality ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%20Outcome%20of%20Consciously%20Creating%20Reality%209745028b1aa74fa5a9c99b592f7d6501.md)

[The Perfect Reality Finds You ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%20Perfect%20Reality%20Finds%20You%20111224dcb5fa47158a849fd74500dece.md)

[A Reinterpretation of Afterlife ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/A%20Reinterpretation%20of%20Afterlife%2001f579ce9ec24e91818ed17b89c93935.md)

[A Reinterpretation of Rebirth ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/A%20Reinterpretation%20of%20Rebirth%205951dcc49495436bbc17109c7b061abb.md)

[Real Teachers](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Real%20Teachers%20d8e8128b26214b0a97e718600c33f442.md)

[A Brief Model of Awakening Consciousness](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/A%20Brief%20Model%20of%20Awakening%20Consciousness%2024e56641de6141c081d6cc4e407568a1.md)

[Crypto: The Metaphor to Artificiality](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Crypto%20The%20Metaphor%20to%20Artificiality%20e21a8b75efa54545b2ad6566a0eba9bb.md)

[To Everyone Who Hates God ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/To%20Everyone%20Who%20Hates%20God%20f02a685270d44923874f7be79352c831.md)

[Two Ways to Actualize Change ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Two%20Ways%20to%20Actualize%20Change%208febb69ad3034d2abe26708a2d4e0942.md)

[Brahman’s Cheat Code](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Brahman%E2%80%99s%20Cheat%20Code%20ca75d1145e494b6c8e9848e1c0bbb5e8.md)

[Orbit, Color, Connection ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Orbit,%20Color,%20Connection%20c97ecb3671ec463399effe8f87a67714.md)

[Mark - Divi Interpretations ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Mark%20-%20Divi%20Interpretations%20fd0a672d055c4143a1f0c6ef031cd9cf.md)

[To Be and Not ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/To%20Be%20and%20Not%20412a5a09236b40a985be66884f98772b.md)

[Antidote to Heaviness](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Antidote%20to%20Heaviness%20825bd21a8dbd4b61a3daa7c59b4841af.md)

[The Presence of Eternity is Near](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%20Presence%20of%20Eternity%20is%20Near%20416a44d44c604bffb9bd0d4a045e6566.md)

[Tonight — The Shift in Human Consciousness  ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Tonight%20%E2%80%94%20The%20Shift%20in%20Human%20Consciousness%20da779f67799541d8bdeb9e73d0bbcff5.md)

[Writings on the Awareness](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Writings%20on%20the%20Awareness%20fd5cad1bb1cc4cb4a0df7d7b1a308782.md)

[Deeper Into The Shadow ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Deeper%20Into%20The%20Shadow%20161b49f8c9bc4a5b8296edd83a1bbd5e.md)

[Radical Self-Compassion](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Radical%20Self-Compassion%207ac05008ca6941c9886a94a6d808ce52.md)

[Project Inspiration WAR — Vision ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Project%20Inspiration%20WAR%20%E2%80%94%20Vision%207e94c2ae4186466d9c2cc08156a35563.md)

---

- In progress*:*
    
    *How to Fall Apart* 
    
    *Energy Abundance*
    
    *Defining Whole* 
    
    *Man’s Largest Problem* 
    
    *Validation* 
    
    *Absolutely Assured* 
    
    *Priority* 
    
    *Alethia 
    Remember Your End* 
    
    *Living Blamelessly* 
    
    *Real Selves*
    
    *Qualification of Deserving* 
    
    *Rebellion* 
    
    *Struggle of Self* 
    

---

 [✨](https://thezenmaster.medium.com/?source=post_page-----705b7b6ad5d3--------------------------------) **2022-2023 Writings:**

[2022 Writings](https://divicorner.art/)

[✨](https://thezenmaster.medium.com/?source=post_page-----705b7b6ad5d3--------------------------------) **2022-2023 Blog Articles:** 

*FLOWMAKER Articles - to be updated*

**2019-2021 Blog Articles:** 

[A Message](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/A%20Message%204a434841d6594a83851ad5c6557c23da.md)

[Change the World ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Change%20the%20World%2062246eacea4d4cd39f1b8305a3debfaa.md)

[Infecting The Script](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Infecting%20The%20Script%2007b7155caca6439185fa01ec90a48ee2.md)

[Hacking the Future](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Hacking%20the%20Future%2069ad83953a074614a13ca0f82188c429.md)

[Delivery Transcends Content](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Delivery%20Transcends%20Content%205ca53f8447114e3785b6d2acd60c4e35.md)

[The Perfect Voice](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%20Perfect%20Voice%20d2496e1ed43b4dbcb2cd559bc43ee638.md)

[Capturing It](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Capturing%20It%201b06479f96154f0ca7bb09b3db3d7c07.md)

[Design](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Design%208d6f389c0fef4cd38369bae089581223.md)

[Repetition](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Repetition%2087106aa8c8b8424786e7e1e2ea90e259.md)

[Listener’s Reward](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Listener%E2%80%99s%20Reward%20dfde3cccac384df5839080296fdd2397.md)

---

# Works

📖 [**The Gospel of Love**](https://github.com/motibytes/The-Gospel-of-Love/blob/main/TheGospelofLove.md) 

📖 [**The Gospel of Love 2**](https://github.com/motibytes/The-Gospel-of-Love-2/blob/main/TheGospelofLove2.md) 

---

# The Blog

[✨](https://thezenmaster.medium.com/?source=post_page-----705b7b6ad5d3--------------------------------) [The Zen Master - Blog](https://thezenmaster.medium.com/)

[The Great Divinie 🧞✨ – Medium](https://thezenmaster.medium.com/)

---

# Entertainment Writings

[The Universe in Starfield in Terms of Role Play Story Building](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%20Universe%20in%20Starfield%20in%20Terms%20of%20Role%20Play%20St%202acf98a4a24441bb84f407c38ad4c146.md)

# The Library

📚 [goodreads](https://www.goodreads.com/user/show/135257757-james-the-blessed)

[The Blessed (jamesbytes) - Zurich, 25, Switzerland (126 books)](https://www.goodreads.com/user/show/135257757-james-the-blessed)

[The 5 that make the Grade](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/The%205%20that%20make%20the%20Grade%202812c820ca7a4594a4e4d83a87edca97.md)

[Laurie Day’s Love Letters ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Laurie%20Day%E2%80%99s%20Love%20Letters%203b7ccd857d574f2084784b1250e91887.md)

---

# Crypto

🧊 [**A Mystery Cubes Club!](https://amysterycubesclub.com/home)** 

[A Mystery Cubes Club!](https://amysterycubesclub.com/home)

[Road to Blockchain Development](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Road%20to%20Blockchain%20Development%200acb82d1f81146f5a526c238a6bf66c2.md)

---

# Videogame Development

[Divi’s Game Development Journey ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Divi%E2%80%99s%20Game%20Development%20Journey%20cfdc2afa27fb4fe699082291a5abb4db.md)

---

# Art

[I Imagine Life Wallpapers ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/I%20Imagine%20Life%20Wallpapers%207e1b673f22e14b9aa2650b0510450df7.md)

🌗 [**LightDark.art**](https://lightdark.art/)

---

# Projects

[Projects ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Projects%20d69a3203bcc2470bb1ad036e9e1ad7a9.md)

---

# Data for Sale

💽 [FLOWCREATOR Store](https://flowcreator.gumroad.com/)

---

# Story

[My ‘Spiritual Experiences’](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/My%20%E2%80%98Spiritual%20Experiences%E2%80%99%20842e993269db48ccabc65b844cba79bb.md)

[My ‘Awakenings’ ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/My%20%E2%80%98Awakenings%E2%80%99%2039eabf8d9c0840bdb110d9c2a329906a.md)

### Journal - Madness

[09/18/23](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/09%2018%2023%20b350717044d542d587d9af5f83a4769b.md)

[09 / 17 / 23 ](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/09%2017%2023%20e9dd71dcb7b84ecb9da0fa257d8ab3ad.md)

### Deeper Spirituality -

**New Publication - The Zen Master** 

[The Zen Master](https://the-zen-master.ghost.io/)

---

# Contact

Contact me at [FlowCreator.app.](http://flowcreator.app)

---

# Donations

If you feel you have gained value from this content, please don't hesitate to leave a token of appreciation matching the value you feel you received on cash app to my handle, $HeavenisGreen. 

[ If you're feeling generous, feel free to send tips! ] 

---

[.](Perspective%20Writings%20and%20More%2044bf4f62b7ff48c29d2f42b0c75c93df/Untitled%20e6c7b74979e04bdebbece6649f0f507e.md)